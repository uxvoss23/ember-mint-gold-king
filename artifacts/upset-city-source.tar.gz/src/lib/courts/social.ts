import { create } from "zustand";
import { persist } from "zustand/middleware";

export type WorkOrderKind = "broken_rim" | "replace_net" | "other";
export type WorkOrderStatus = "submitted" | "received" | "in_progress" | "resolved";

export interface CourtReview {
  id: string;
  courtId: string;
  author: string;
  rating: number; // 1–5
  text: string;
  at: string;
}

export interface WorkOrder {
  id: string;
  courtId: string;
  courtName?: string;
  kind: WorkOrderKind;
  detail?: string;
  at: string;
  status: WorkOrderStatus;
  /** Who filed it (display) */
  reporter?: string;
  /** Optional photo (data URL or remote) — first image */
  photoUrl?: string;
  /** All attached photos (includes photoUrl as first when present) */
  photos?: string[];
}

interface CourtSocialState {
  reviews: CourtReview[];
  favoriteBonus: Record<string, number>;
  workOrders: WorkOrder[];
  addReview: (courtId: string, rating: number, text: string, author?: string) => void;
  addWorkOrder: (
    courtId: string,
    kind: WorkOrderKind,
    detail?: string,
    meta?: {
      courtName?: string;
      reporter?: string;
      photoUrl?: string;
      photos?: string[];
    },
  ) => void;
  setWorkOrderStatus: (id: string, status: WorkOrderStatus) => void;
  bumpFavorite: (courtId: string) => void;
}

function hashCount(id: string, min: number, max: number) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  const n = Math.abs(h);
  return min + (n % (max - min + 1));
}

export function baseFavoriteCount(courtId: string) {
  return hashCount(courtId, 4, 48);
}

const SEED_REVIEWS: CourtReview[] = [
  {
    id: "r1",
    courtId: "cat-zilker",
    author: "Marcus H.",
    rating: 5,
    text: "Best outdoor run in central Austin. Bring water on weekends.",
    at: "2026-07-12T18:00:00.000Z",
  },
  {
    id: "r2",
    courtId: "cat-battle-bend",
    author: "Cam O.",
    rating: 4,
    text: "Solid surface, gets busy Friday nights. Nets are good.",
    at: "2026-07-20T19:30:00.000Z",
  },
  {
    id: "r3",
    courtId: "cat-givens",
    author: "Sean R.",
    rating: 5,
    text: "East side staple. Lights until late. Competitive but fair.",
    at: "2026-07-28T21:00:00.000Z",
  },
  {
    id: "r4",
    courtId: "cat-pease",
    author: "Jia N.",
    rating: 4,
    text: "Shady in the afternoon. Great for kids earlier, then adult runs.",
    at: "2026-08-01T16:00:00.000Z",
  },
  {
    id: "r5",
    courtId: "cat-bartholomew",
    author: "Riley C.",
    rating: 3,
    text: "Courts are fine — one rim is a little soft. Still playable.",
    at: "2026-07-15T17:00:00.000Z",
  },
];

const SEED_ORDERS: WorkOrder[] = [
  {
    id: "wo-seed-1",
    courtId: "cat-bartholomew",
    courtName: "Bartholomew District Park",
    kind: "broken_rim",
    at: "2026-08-03T15:20:00.000Z",
    status: "submitted",
    reporter: "Riley C.",
  },
  {
    id: "wo-seed-2",
    courtId: "cat-rosewood",
    courtName: "Rosewood Park",
    kind: "replace_net",
    at: "2026-08-04T19:05:00.000Z",
    status: "received",
    reporter: "Marcus H.",
  },
];

export const useCourtSocial = create<CourtSocialState>()(
  persist(
    (set) => ({
      reviews: SEED_REVIEWS,
      favoriteBonus: {},
      workOrders: SEED_ORDERS,
      addReview: (courtId, rating, text, author = "You") => {
        const t = text.trim();
        if (!t) return;
        set((s) => ({
          reviews: [
            {
              id: `r-${Date.now().toString(36)}`,
              courtId,
              author,
              rating: Math.min(5, Math.max(1, rating)),
              text: t,
              at: new Date().toISOString(),
            },
            ...s.reviews,
          ],
        }));
      },
      addWorkOrder: (courtId, kind, detail, meta) => {
        set((s) => ({
          workOrders: [
            {
              id: `wo-${Date.now().toString(36)}`,
              courtId,
              courtName: meta?.courtName,
              kind,
              detail: detail?.trim() || undefined,
              at: new Date().toISOString(),
              status: "submitted",
              reporter: meta?.reporter ?? "Player",
              photoUrl: meta?.photos?.[0] ?? meta?.photoUrl,
              photos:
                meta?.photos && meta.photos.length
                  ? meta.photos
                  : meta?.photoUrl
                    ? [meta.photoUrl]
                    : undefined,
            },
            ...s.workOrders,
          ],
        }));
      },
      setWorkOrderStatus: (id, status) => {
        set((s) => ({
          workOrders: s.workOrders.map((w) =>
            w.id === id ? { ...w, status } : w,
          ),
        }));
      },
      bumpFavorite: (courtId) => {
        set((s) => ({
          favoriteBonus: {
            ...s.favoriteBonus,
            [courtId]: (s.favoriteBonus[courtId] ?? 0) + 1,
          },
        }));
      },
    }),
    { name: "court-social-v3" },
  ),
);

export function favoriteCountFor(
  courtId: string,
  userFavorited: boolean,
  bonus: Record<string, number>,
) {
  return baseFavoriteCount(courtId) + (bonus[courtId] ?? 0) + (userFavorited ? 0 : 0);
}

export function reviewsFor(reviews: CourtReview[], courtId: string) {
  return reviews.filter((r) => r.courtId === courtId);
}

export const WORK_ORDER_LABELS: Record<WorkOrderKind, string> = {
  broken_rim: "Broken rim",
  replace_net: "Replace net",
  other: "Something else",
};

export const WORK_ORDER_STATUS_LABELS: Record<WorkOrderStatus, string> = {
  submitted: "New",
  received: "Received",
  in_progress: "In progress",
  resolved: "Resolved",
};

// Admin is email-gated — see `@/lib/auth/admin` (seanvoss23@gmail.com)
