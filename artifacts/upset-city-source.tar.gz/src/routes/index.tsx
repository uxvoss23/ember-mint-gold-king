import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { User } from "lucide-react";
import { SceneShell } from "@/components/compete/scene-shell";
import { DEFAULT_CITY } from "@/lib/courts/catalog";
import { fetchCourtsNear } from "@/lib/courts/fetch-courts";
import type { Court, UserLocation } from "@/lib/courts/types";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { milesToMeters } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const AUSTIN: UserLocation = {
  lat: DEFAULT_CITY.lat,
  lon: DEFAULT_CITY.lon,
  label: "Austin, TX",
};

function Home() {
  const [location, setLocation] = useState<UserLocation | null>(AUSTIN);
  const [courts, setCourts] = useState<Court[]>([]);
  const [loading, setLoading] = useState(true);
  const [locating, setLocating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locError, setLocError] = useState<string | null>(null);
  const [radiusMi, setRadiusMi] = useState(8);
  const [dataSource, setDataSource] = useState<string>("");
  const { isPending: authPending } = useCurrentUserState();
  const locationRef = useRef<UserLocation | null>(AUSTIN);
  const skipRadiusEffect = useRef(true);
  const bootstrapped = useRef(false);

  const loadCourts = useCallback(async (loc: UserLocation, miles: number) => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchCourtsNear({
        data: {
          lat: loc.lat,
          lon: loc.lon,
          radiusMeters: Math.round(milesToMeters(miles)),
          label: loc.label,
        },
      });
      setCourts(result.courts);
      setDataSource(result.source);
      setLocation(result.location);
      locationRef.current = result.location;
    } catch (e) {
      console.error(e);
      setError("Couldn’t load courts. Try again or pick another city.");
      setCourts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (bootstrapped.current) return;
    bootstrapped.current = true;
    void loadCourts(AUSTIN, 8);
  }, [loadCourts]);

  const requestLocation = useCallback(() => {
    setLocError(null);
    if (!navigator.geolocation) {
      setLocError("Location isn’t available. Showing Austin courts instead.");
      void loadCourts(AUSTIN, radiusMi);
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const loc: UserLocation = {
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
          label: "Near you",
        };
        locationRef.current = loc;
        setLocation(loc);
        setLocating(false);
        void loadCourts(loc, radiusMi);
      },
      () => {
        setLocating(false);
        setLocError("Couldn’t get your location. Showing Austin.");
        void loadCourts(AUSTIN, radiusMi);
      },
      { enableHighAccuracy: true, timeout: 12000 },
    );
  }, [loadCourts, radiusMi]);

  useEffect(() => {
    if (skipRadiusEffect.current) {
      skipRadiusEffect.current = false;
      return;
    }
    const loc = locationRef.current;
    if (loc) void loadCourts(loc, radiusMi);
  }, [radiusMi, loadCourts]);

  return (
    <div className="app-shell mx-auto flex w-full max-w-lg flex-col bg-bg">
      <header className="sticky top-[var(--grok-banner-h,0px)] z-30 border-b border-border/80 bg-bg/90 px-4 pt-2.5 pb-2.5 backdrop-blur-md safe-pt">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="font-display truncate text-base font-semibold tracking-tight text-fg">
              <span className="text-court">Upset City</span>
              <span className="mx-1.5 text-fg-subtle font-normal">·</span>
              <span>{location?.label ?? "Austin, TX"}</span>
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {authPending ? (
              <div className="size-9 animate-pulse rounded-full bg-bg-subtle" />
            ) : (
              <>
                <SignedIn>
                  <UserButton />
                </SignedIn>
                <SignedOut>
                  <Link
                    to="/login"
                    className="flex size-9 items-center justify-center rounded-full border border-border bg-bg-elevated text-fg-muted"
                    aria-label="Sign in"
                  >
                    <User className="size-4" strokeWidth={1.75} />
                  </Link>
                </SignedOut>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col px-4 pt-4 pb-4">
        {location ? (
          <SceneShell
            courts={courts}
            location={location}
            courtsLoading={loading}
            courtsLocating={locating}
            courtsError={error}
            courtsLocError={locError}
            radiusMi={radiusMi}
            dataSource={dataSource}
            onRadiusChange={setRadiusMi}
            onRefreshCourts={() =>
              location && void loadCourts(location, radiusMi)
            }
            onNearMe={requestLocation}
          />
        ) : (
          <p className="text-center text-sm text-fg-muted">Loading…</p>
        )}
      </main>
    </div>
  );
}
