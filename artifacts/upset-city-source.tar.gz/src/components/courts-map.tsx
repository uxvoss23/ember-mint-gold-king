import { useEffect, useRef, useState } from "react";
import type { Court, UserLocation } from "@/lib/courts/types";
import type { Player } from "@/lib/upset/types";
import { cn } from "@/lib/utils";

interface CourtsMapProps {
  courts: Court[];
  location: UserLocation;
  selectedId?: string | null;
  onSelect: (court: Court) => void;
  kings?: Record<string, Player | null | undefined>;
  openGames?: Record<string, number>;
  /** Finder mode: simple pins + hover name labels */
  variant?: "scene" | "finder";
}

type MapStyle = "satellite" | "street";

export function CourtsMap({
  courts,
  location,
  selectedId,
  onSelect,
  kings = {},
  openGames = {},
  variant = "scene",
}: CourtsMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("maplibre-gl").Map | null>(null);
  const markersRef = useRef<import("maplibre-gl").Marker[]>([]);
  const [style, setStyle] = useState<MapStyle>("street");
  const [ready, setReady] = useState(false);
  const [zoomTick, setZoomTick] = useState(0);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!containerRef.current || mapRef.current) return;
      const maplibregl = await import("maplibre-gl");
      await import("maplibre-gl/dist/maplibre-gl.css");
      if (cancelled || !containerRef.current) return;

      const map = new maplibregl.Map({
        container: containerRef.current,
        style: STREET_STYLE,
        center: [location.lon, location.lat],
        zoom: 11.2,
        attributionControl: { compact: true },
      });
      map.addControl(
        new maplibregl.NavigationControl({ showCompass: false }),
        "bottom-right",
      );
      mapRef.current = map;
      map.on("load", () => {
        if (!cancelled) {
          setReady(true);
          map.resize();
        }
      });
      map.on("zoomend", () => setZoomTick((t) => t + 1));
    })();

    return () => {
      cancelled = true;
      markersRef.current.forEach((m) => m.remove());
      markersRef.current = [];
      mapRef.current?.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready) return;
    const center = map.getCenter();
    const zoom = map.getZoom();
    map.setStyle(style === "satellite" ? SATELLITE_STYLE : STREET_STYLE);
    map.once("style.load", () => {
      map.setCenter(center);
      map.setZoom(zoom);
    });
  }, [style, ready]);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    let cancelled = false;
    (async () => {
      const maplibregl = await import("maplibre-gl");
      const map = mapRef.current;
      if (!map || cancelled) return;

      markersRef.current.forEach((m) => m.remove());
      markersRef.current = [];

      const youEl = document.createElement("div");
      youEl.innerHTML = `<div class="uc-you"></div>`;
      markersRef.current.push(
        new maplibregl.Marker({ element: youEl, anchor: "center" })
          .setLngLat([location.lon, location.lat])
          .addTo(map),
      );

      const zoom = map.getZoom();
      const cluster = zoom < 11.5 && courts.length > 8;

      const placePin = (c: Court) => {
        const king = kings[c.id];
        const open = openGames[c.id] ?? 0;
        const selected = c.id === selectedId;
        const el = document.createElement("div");
        el.className = [
          "uc-pin",
          variant === "finder" ? "uc-pin-finder-wrap" : "",
          selected ? "uc-pin-selected" : "",
          variant !== "finder" && !king ? "uc-pin-open" : "",
        ]
          .filter(Boolean)
          .join(" ");

        const initials = king
          ? king.name
              .split(" ")
              .map((w) => w[0])
              .join("")
              .slice(0, 2)
          : "";

        const isFinder = variant === "finder";
        el.innerHTML = isFinder
          ? `
          <div class="uc-pin-face uc-pin-finder">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="10" r="3"/><path d="M12 21s7-4.5 7-11a7 7 0 1 0-14 0c0 6.5 7 11 7 11z"/></svg>
          </div>
          <div class="uc-pin-hover">${esc(c.name)}</div>
          ${selected ? `<div class="uc-pin-label">${esc(c.name)}</div>` : ""}
        `
          : `
          <div class="uc-pin-face" style="${king ? `background:oklch(0.42 0.08 ${king.hue})` : ""}">
            ${
              king
                ? `<span>${initials}</span>`
                : `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>`
            }
          </div>
          ${open > 0 ? `<span class="uc-badge">${open}</span>` : ""}
          <div class="uc-pin-hover">${esc(c.name)}</div>
          ${
            selected
              ? `<div class="uc-pin-label">${esc(c.name)}${king ? ` · ${esc(king.name)} runs this court` : " · Unclaimed"}</div>`
              : !king
                ? `<div class="uc-pin-sub">Unclaimed</div>`
                : ""
          }
        `;
        // Hover / focus label for finder (and scene when not selected)
        const labelEl = el.querySelector(".uc-pin-hover") as HTMLElement | null;
        el.addEventListener("mouseenter", () => {
          el.classList.add("uc-pin-hovering");
        });
        el.addEventListener("mouseleave", () => {
          el.classList.remove("uc-pin-hovering");
        });
        el.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelectRef.current(c);
        });
        void labelEl;
        markersRef.current.push(
          new maplibregl.Marker({ element: el, anchor: "center" })
            .setLngLat([c.lon, c.lat])
            .addTo(map),
        );
      };

      if (cluster) {
        const buckets = new Map<string, Court[]>();
        for (const c of courts) {
          const key = `${c.lat.toFixed(2)},${c.lon.toFixed(2)}`;
          const arr = buckets.get(key) ?? [];
          arr.push(c);
          buckets.set(key, arr);
        }
        for (const group of buckets.values()) {
          if (group.length === 1) {
            placePin(group[0]!);
          } else {
            const lat = group.reduce((s, c) => s + c.lat, 0) / group.length;
            const lon = group.reduce((s, c) => s + c.lon, 0) / group.length;
            const el = document.createElement("div");
            el.className = "uc-cluster";
            el.textContent = String(group.length);
            el.onclick = () =>
              map.easeTo({ center: [lon, lat], zoom: Math.min(zoom + 2.2, 14) });
            markersRef.current.push(
              new maplibregl.Marker({ element: el, anchor: "center" })
                .setLngLat([lon, lat])
                .addTo(map),
            );
          }
        }
      } else {
        for (const c of courts.slice(0, 50)) placePin(c);
      }

      // neighborhood banners
      if (zoom < 13) {
        const zones = new Map<string, { lat: number; lon: number; n: number }>();
        for (const c of courts) {
          if (!c.neighborhood) continue;
          const z = zones.get(c.neighborhood) ?? { lat: 0, lon: 0, n: 0 };
          z.lat += c.lat;
          z.lon += c.lon;
          z.n += 1;
          zones.set(c.neighborhood, z);
        }
        for (const [name, z] of zones) {
          const el = document.createElement("div");
          el.className = "uc-zone";
          el.textContent = name;
          markersRef.current.push(
            new maplibregl.Marker({ element: el, anchor: "center" })
              .setLngLat([z.lon / z.n, z.lat / z.n])
              .addTo(map),
          );
        }
      }

      if (courts.length > 0 && zoomTick === 0) {
        const bounds = new maplibregl.LngLatBounds();
        bounds.extend([location.lon, location.lat]);
        for (const c of courts.slice(0, 40)) bounds.extend([c.lon, c.lat]);
        map.fitBounds(bounds, { padding: 48, maxZoom: 13, duration: 500 });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [courts, location, selectedId, kings, openGames, ready, zoomTick, variant]);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-bg-elevated">
      <div ref={containerRef} className="uc-map aspect-[4/5] w-full sm:aspect-[16/11]" />
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-bg-elevated">
          <div className="h-8 w-8 animate-pulse rounded-full bg-bg-subtle" />
        </div>
      )}
      <div className="absolute top-3 left-3 z-10 flex rounded-full border border-border bg-bg/90 p-0.5 shadow-soft backdrop-blur-md">
        {(
          [
            { id: "street" as const, label: "Street" },
            { id: "satellite" as const, label: "Satellite" },
          ] as const
        ).map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setStyle(s.id)}
            className={cn(
              "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
              style === s.id ? "bg-accent text-accent-fg" : "text-fg-muted hover:text-fg",
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
      <div className="absolute right-3 bottom-10 z-10 rounded-full border border-border bg-bg/85 px-2.5 py-1 text-[11px] font-medium text-fg-muted backdrop-blur-sm">
        {courts.length} courts
      </div>
    </div>
  );
}

function esc(s: string) {
  return s
    .replace(/&/g, "&" + "amp;")
    .replace(/</g, "&" + "lt;")
    .replace(/>/g, "&" + "gt;")
    .replace(/"/g, "&" + "quot;")
    .replace(/'/g, "&#39;");
}

const STREET_STYLE: import("maplibre-gl").StyleSpecification = {
  version: 8,
  name: "Upset City Street",
  sources: {
    carto: {
      type: "raster",
      tiles: [
        "https://a.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}@2x.png",
        "https://b.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}@2x.png",
      ],
      tileSize: 256,
      attribution: "&copy; OSM &copy; CARTO",
    },
  },
  layers: [
    { id: "bg", type: "background", paint: { "background-color": "#e8e0d4" } },
    {
      id: "carto",
      type: "raster",
      source: "carto",
      paint: {
        "raster-saturation": -0.35,
        "raster-contrast": -0.08,
        "raster-brightness-min": 0.04,
        "raster-brightness-max": 0.9,
        "raster-opacity": 0.94,
      },
    },
  ],
};

const SATELLITE_STYLE: import("maplibre-gl").StyleSpecification = {
  version: 8,
  name: "Upset City Satellite",
  sources: {
    esri: {
      type: "raster",
      tiles: [
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      ],
      tileSize: 256,
      attribution: "Tiles &copy; Esri",
    },
  },
  layers: [
    {
      id: "esri",
      type: "raster",
      source: "esri",
      paint: { "raster-saturation": -0.12, "raster-contrast": 0.06 },
    },
  ],
};
