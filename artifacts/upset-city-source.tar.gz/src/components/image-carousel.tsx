import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImageCarouselProps {
  images: string[];
  alt?: string;
  className?: string;
  priority?: boolean;
  showControls?: boolean;
}

/**
 * Swipeable photo strip — swipe, dots, or edge-tucked chevrons.
 */
export function ImageCarousel({
  images,
  alt = "",
  className,
  priority,
  showControls = true,
}: ImageCarouselProps) {
  const [index, setIndex] = useState(0);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const startX = useRef(0);
  const startScroll = useRef(0);

  const count = images.length;

  const goTo = useCallback(
    (i: number) => {
      const next = ((i % count) + count) % count;
      setIndex(next);
      const el = scrollerRef.current;
      if (!el) return;
      el.scrollTo({ left: next * el.clientWidth, behavior: "smooth" });
    },
    [count],
  );

  const go = useCallback(
    (dir: -1 | 1) => {
      goTo(index + dir);
    },
    [goTo, index],
  );

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const w = el.clientWidth || 1;
        const i = Math.round(el.scrollLeft / w);
        setIndex((prev) => (i !== prev && i >= 0 && i < count ? i : prev));
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [count]);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      el.scrollLeft = index * el.clientWidth;
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [index]);

  if (count === 0) return null;

  return (
    <div
      className={cn(
        "group/carousel relative isolate overflow-hidden bg-bg-subtle",
        className,
      )}
    >
      <div
        ref={scrollerRef}
        className="flex h-full w-full snap-x snap-mandatory overflow-x-auto overflow-y-hidden overscroll-x-contain [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        style={{ WebkitOverflowScrolling: "touch", touchAction: "pan-x" }}
        onPointerDown={(e) => {
          if (e.pointerType === "mouse" && e.button !== 0) return;
          dragging.current = true;
          startX.current = e.clientX;
          startScroll.current = scrollerRef.current?.scrollLeft ?? 0;
        }}
        onPointerMove={(e) => {
          if (!dragging.current || !scrollerRef.current) return;
          if (e.pointerType === "mouse") {
            scrollerRef.current.scrollLeft =
              startScroll.current - (e.clientX - startX.current);
          }
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
        onPointerCancel={() => {
          dragging.current = false;
        }}
      >
        {images.map((src, i) => (
          <div
            key={`${src}-${i}`}
            className="h-full w-full shrink-0 grow-0 basis-full snap-center snap-always"
          >
            <img
              src={src}
              alt={i === 0 ? alt : ""}
              draggable={false}
              className="h-full w-full object-cover object-center select-none"
              loading={priority && i === 0 ? "eager" : "lazy"}
              decoding="async"
            />
          </div>
        ))}
      </div>

      {count > 1 && (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-black/30 to-transparent" />
      )}

      {count > 1 && (
        <div className="absolute bottom-2 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1">
          {images.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goTo(i);
              }}
              className={cn(
                "h-1 rounded-full transition-all",
                i === index ? "w-3 bg-white" : "w-1 bg-white/50",
              )}
              aria-label={`Photo ${i + 1} of ${count}`}
            />
          ))}
        </div>
      )}

      {/* Edge-tucked arrows — flush to sides, low contrast */}
      {showControls && count > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              go(-1);
            }}
            className="absolute top-1/2 left-0 z-20 flex h-12 w-7 -translate-y-1/2 items-center justify-start rounded-r-full bg-black/25 pl-0.5 text-white/80 backdrop-blur-[1px] transition-colors hover:bg-black/40 hover:text-white"
            aria-label="Previous photo"
          >
            <ChevronLeft className="size-4" strokeWidth={2} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              go(1);
            }}
            className="absolute top-1/2 right-0 z-20 flex h-12 w-7 -translate-y-1/2 items-center justify-end rounded-l-full bg-black/25 pr-0.5 text-white/80 backdrop-blur-[1px] transition-colors hover:bg-black/40 hover:text-white"
            aria-label="Next photo"
          >
            <ChevronRight className="size-4" strokeWidth={2} />
          </button>
        </>
      )}
    </div>
  );
}
