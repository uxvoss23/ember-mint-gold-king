import { useEffect, useState } from "react";
import { Bell, CalendarPlus } from "lucide-react";
import {
  downloadMatchIcs,
  googleCalendarUrl,
  markReminder,
  reminderState,
  remindersCompleted,
  scheduleBrowserReminders,
  type ReminderMatch,
} from "@/lib/match-reminders";

/**
 * One-shot card: after calendar is added (or user dismisses), it stays gone.
 */
export function MatchRemindersCard({ match }: { match: ReminderMatch }) {
  const [hidden, setHidden] = useState(() => remindersCompleted(match.id));
  const [flash, setFlash] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const tip = new Date(match.whenIso);
  const tooSoon = tip.getTime() - Date.now() < 30 * 60e3;

  // If another tab already completed it, stay hidden
  useEffect(() => {
    if (remindersCompleted(match.id)) setHidden(true);
  }, [match.id]);

  const finish = (message: string) => {
    setFlash(message);
    setHidden(true);
    window.setTimeout(() => setFlash(null), 1600);
  };

  const onCalendar = () => {
    downloadMatchIcs(match);
    markReminder(match.id, "calendar");
    finish("Added — check your calendar. Alerts: 24h & 3h before.");
  };

  const onGoogle = () => {
    window.open(googleCalendarUrl(match), "_blank", "noopener,noreferrer");
    markReminder(match.id, "calendar");
    finish("Opening Google Calendar — set 1 day + 3 hour alerts if asked.");
  };

  const onBrowser = async () => {
    setBusy(true);
    const r = await scheduleBrowserReminders(match);
    setBusy(false);
    if (r.ok) {
      // Browser alone doesn't count as full complete unless they want — still hide
      // only if they also had calendar? User said after calendar done. Keep browser optional.
      const s = reminderState(match.id);
      if (s.calendar) finish("Browser alerts on.");
      else {
        setFlash(
          "Browser alerts on. Still recommend Add to calendar for phone lock-screen pings.",
        );
        window.setTimeout(() => setFlash(null), 2500);
      }
    } else {
      setFlash(r.reason ?? "Couldn’t set browser alerts.");
      window.setTimeout(() => setFlash(null), 2500);
    }
  };

  const onDismiss = () => {
    markReminder(match.id, "dismissed");
    setHidden(true);
  };

  if (hidden) {
    if (!flash) return null;
    return (
      <p
        className="rounded-xl border border-success/30 bg-success/10 px-3 py-2.5 text-center text-xs font-medium text-success"
        role="status"
      >
        {flash}
      </p>
    );
  }

  return (
    <div className="rounded-2xl border border-court/30 bg-court-soft/30 p-3.5">
      <div className="flex items-start gap-2">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-court text-white">
          <Bell className="size-4" strokeWidth={2} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-fg">Game reminders</p>
          <p className="mt-0.5 text-[11px] leading-snug text-fg-muted">
            Ping you <span className="font-semibold text-fg">24 hours</span> and{" "}
            <span className="font-semibold text-fg">3 hours</span> before tip-off.
            Add once — this card won’t show again.
          </p>
        </div>
      </div>

      <div className="mt-3 flex flex-col gap-2">
        <button
          type="button"
          onClick={onCalendar}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-fg text-sm font-semibold text-bg"
        >
          <CalendarPlus className="size-4" />
          Add to phone calendar
        </button>
        <button
          type="button"
          onClick={onGoogle}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-border bg-bg-elevated text-xs font-semibold text-fg"
        >
          Open in Google Calendar
        </button>
        {!tooSoon ? (
          <button
            type="button"
            disabled={busy}
            onClick={() => void onBrowser()}
            className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-border text-xs font-semibold text-fg-muted disabled:opacity-60"
          >
            <Bell className="size-3.5" />
            {busy ? "Setting…" : "Also set browser alerts"}
          </button>
        ) : null}
        <button
          type="button"
          onClick={onDismiss}
          className="py-1 text-center text-[11px] font-medium text-fg-subtle"
        >
          Not now
        </button>
      </div>

      {flash ? (
        <p className="mt-2 text-[11px] leading-snug text-fg-muted" role="status">
          {flash}
        </p>
      ) : null}
    </div>
  );
}
