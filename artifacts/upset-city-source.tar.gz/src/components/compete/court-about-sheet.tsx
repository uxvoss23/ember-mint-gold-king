import { useEffect } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { ImageCarousel } from "@/components/image-carousel";
import type { Court } from "@/lib/courts/types";
import { courtImagesFor } from "@/lib/courts/images";
import { cn } from "@/lib/utils";

export type AboutCourt =
  | (Court & { miles?: number })
  | {
      id: string;
      name: string;
      lat?: number;
      lon?: number;
      address?: string;
      neighborhood?: string;
      notes?: string;
      surface?: string;
      hoops?: number;
      amenities?: string[];
      miles?: number;
    };

function formatMiles(mi: number) {
  if (mi < 0.1) return "<0.1 mi";
  if (mi < 10) return `${mi.toFixed(1)} mi`;
  return `${Math.round(mi)} mi`;
}

export function courtAboutText(court: {
  name: string;
  neighborhood?: string;
  notes?: string;
  surface?: string;
  hoops?: number;
  amenities?: string[];
}) {
  if (court.notes?.trim()) return court.notes.trim();
  const bits = [
    court.neighborhood
      ? `${court.neighborhood} outdoor courts`
      : "Public outdoor courts",
    court.hoops
      ? `${court.hoops} hoop${court.hoops === 1 ? "" : "s"}`
      : null,
    court.surface && court.surface !== "unknown"
      ? `${court.surface} surface`
      : null,
  ].filter(Boolean);
  return `${bits.join(" · ")}. Upset City is still writing a full take on this spot.`;
}

/**
 * Court info popup — portaled to body so it sits above map/create scroll.
 * Image stays fixed at top; notes scroll below; actions sticky at bottom.
 */
export function CourtAboutSheet({
  court,
  onClose,
  onSelectCourt,
  isSelected = false,
}: {
  court: AboutCourt | null | undefined;
  onClose: () => void;
  onSelectCourt?: (id: string) => void;
  isSelected?: boolean;
}) {
  useEffect(() => {
    if (!court) return;
    const html = document.documentElement;
    const body = document.body;
    const prevHtml = html.style.overflow;
    const prevBody = body.style.overflow;
    const prevPad = body.style.paddingRight;
    const sb = window.innerWidth - html.clientWidth;
    html.style.overflow = "hidden";
    body.style.overflow = "hidden";
    if (sb > 0) body.style.paddingRight = `${sb}px`;
    return () => {
      html.style.overflow = prevHtml;
      body.style.overflow = prevBody;
      body.style.paddingRight = prevPad;
    };
  }, [court]);

  if (!court) return null;

  const images = courtImagesFor(court.id, 5);
  const about = courtAboutText(court);
  const amenityLabels: Record<string, string> = {
    lights: "Lights",
    full_court: "Full court",
    half_court: "Half court",
    multiple: "Multiple courts",
    water: "Water",
    parking: "Parking",
    fence: "Fenced",
    shade: "Shade",
  };
  const amenities = (court.amenities ?? [])
    .map((a) => amenityLabels[a] ?? a)
    .filter(Boolean);

  const sheet = (
    <div
      className="fixed inset-0 z-[400] flex items-end justify-center bg-black/65 sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="court-about-title"
      onClick={onClose}
    >
      {/* Catch scroll on backdrop so page/map doesn't move */}
      <div
        className="absolute inset-0"
        onWheel={(e) => e.preventDefault()}
        onTouchMove={(e) => e.preventDefault()}
      />
      <div
        className="relative z-10 flex max-h-[min(92dvh,720px)] w-full max-w-md flex-col overflow-hidden rounded-t-2xl border border-border bg-bg shadow-2xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative shrink-0 bg-bg-subtle">
          <ImageCarousel
            images={images}
            alt={court.name}
            className="aspect-[16/10] w-full max-h-[36dvh]"
            showControls
            priority
          />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-3 pb-2.5 pt-10">
            <p className="text-[10px] font-bold tracking-[0.14em] text-court uppercase">
              Upset City · Court notes
            </p>
            <h3
              id="court-about-title"
              className="font-display text-lg font-semibold text-white"
            >
              {court.name}
            </h3>
            <p className="text-xs text-white/85">
              {court.neighborhood ?? "Austin"}
              {"miles" in court && typeof court.miles === "number"
                ? ` · ${formatMiles(court.miles)} away`
                : ""}
              {images.length > 1 ? ` · ${images.length} photos · swipe` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-2 right-2 z-20 rounded-full bg-black/55 p-1.5 text-white"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>

        <div
          className="min-h-0 flex-1 space-y-3 overflow-y-auto overscroll-contain px-4 py-3"
          style={{ WebkitOverflowScrolling: "touch" }}
        >
          <p className="text-sm leading-relaxed text-fg">{about}</p>
          {amenities.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {amenities.map((a) => (
                <span
                  key={a}
                  className="rounded-full border border-border bg-bg-elevated px-2 py-0.5 text-[11px] font-medium text-fg-muted"
                >
                  {a}
                </span>
              ))}
            </div>
          ) : null}
          {court.address ? (
            <p className="text-xs text-fg-subtle">{court.address}</p>
          ) : null}
        </div>

        <div className="shrink-0 border-t border-border bg-bg p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          {onSelectCourt ? (
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 rounded-full border border-border py-2.5 text-sm font-semibold text-fg"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => onSelectCourt(court.id)}
                className={cn(
                  "flex-1 rounded-full py-2.5 text-sm font-semibold text-white",
                  isSelected ? "bg-fg" : "bg-court",
                )}
              >
                {isSelected ? "Selected ✓" : "Select this court"}
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="w-full rounded-full bg-fg py-2.5 text-sm font-semibold text-bg"
            >
              Got it
            </button>
          )}
        </div>
      </div>
    </div>
  );

  if (typeof document === "undefined") return sheet;
  return createPortal(sheet, document.body);
}
