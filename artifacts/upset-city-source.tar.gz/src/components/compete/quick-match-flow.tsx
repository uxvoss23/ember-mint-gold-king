import { useEffect, useMemo, useState } from "react";
import {
  ChevronRight,
  Info,
  LocateFixed,
  MapPin,
  MessageCircle,
  Plus,
  Search,
  UserPlus,
  X,
} from "lucide-react";
import { CourtAboutSheet } from "@/components/compete/court-about-sheet";
import { MatchRemindersCard } from "@/components/compete/match-reminders-card";
import {
  StakeChip,
  StakeSettleCard,
} from "@/components/compete/stake-settle-card";
import { PlayerAvatar } from "@/components/compete/player-avatar";
import { CourtMapCutout } from "@/components/court-map-cutout";
import { CourtsMap } from "@/components/courts-map";
import { ImageCarousel } from "@/components/image-carousel";
import type { Court } from "@/lib/courts/types";
import { courtImagesFor } from "@/lib/courts/images";
import { directionsUrl } from "@/lib/maps/directions";
import { suggestAustinAddresses, type GeoHit } from "@/lib/maps/geocode";
import { displayRating } from "@/lib/rating/engine";
import { CampaignBanner } from "@/components/compete/campaign-banner";
import { ALZHEIMERS_CHARITY, MAX_STAKE_DOLLARS, MIN_STAKE_DOLLARS } from "@/lib/upset/stakes";
import type { MatchFormat, MatchStakes, StakeMode } from "@/lib/upset/types";
import { formatLocalWhen, useUpsetStore } from "@/lib/upset/store";
import type { Match, Player, PlayerReview } from "@/lib/upset/types";
import { cn, formatHeightInches } from "@/lib/utils";

type View = "find" | "game" | "create";
type InviteFilter = "friends" | "available" | "active";
type InviteSortKey = "rating" | "height" | "streak";
const AUSTIN_CENTER = { lat: 30.2672, lon: -97.7431 };
const TWO_WEEKS_MS = 14 * 24 * 60 * 60 * 1000;
const RECOMMENDED_COURT_IDS = new Set([
  "cat-zilker","cat-battle-bend","cat-pease","cat-bartholomew",
  "cat-rosewood","cat-reed","cat-circle-c","cat-west4",
  "cat-garrison","cat-walnut-creek","cat-hancock","cat-searight",
]);
function isShadedCourt(c: { amenities?: string[] }) { return (c.amenities ?? []).includes("shade"); }
function isRecommendedCourt(c: { id: string; amenities?: string[] }) {
  if (RECOMMENDED_COURT_IDS.has(c.id)) return true;
  const a = new Set(c.amenities ?? []);
  return a.has("shade") && a.has("lights") && a.has("parking");
}
function recommendScore(c: { id: string; amenities?: string[]; miles?: number; hoops?: number }) {
  let s = 0;
  if (RECOMMENDED_COURT_IDS.has(c.id)) s += 100;
  const a = new Set(c.amenities ?? []);
  if (a.has("shade")) s += 25; if (a.has("lights")) s += 20; if (a.has("parking")) s += 15;
  if (a.has("multiple")) s += 15; if (a.has("water")) s += 10; if (a.has("fence")) s += 8;
  if ((c.hoops ?? 0) >= 4) s += 12;
  if (typeof c.miles === "number") s += Math.max(0, 10 - c.miles);
  return s;
}
interface QuickMatchFlowProps {
  me: Player; players: Player[]; courts: Court[]; matches: Match[];
  userLat?: number; userLon?: number;
  onCreateMatch?: (input: {
    court: { id: string; name: string; lat: number; lon: number };
    preferredAt: string;
    mode: "ranked_1v1";
    format?: MatchFormat;
    notes?: string;
    stakes?: MatchStakes;
  }) => void;
  onAcceptMatch?: (matchId: string) => "ok" | "filled" | void;
  onOpenPlayer?: (p: Player) => void;
  compactHeader?: boolean;
  onImmersiveChange?: (immersive: boolean) => void;
  /** Deep-link: open this match detail from Media / elsewhere */
  focusMatchId?: string | null;
  onFocusMatchConsumed?: () => void;
}
function haversineMi(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 3958.8; const toR = (d: number) => (d * Math.PI) / 180;
  const dLat = toR(lat2 - lat1); const dLon = toR(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toR(lat1)) * Math.cos(toR(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
function inAustinMetro(lat: number, lon: number) { return lat >= 30.05 && lat <= 30.55 && lon >= -98.05 && lon <= -97.45; }
function formatMiles(mi: number) { if (mi < 0.1) return "<0.1 mi"; if (mi < 10) return `${mi.toFixed(1)} mi`; return `${Math.round(mi)} mi`; }
function whenParts(iso: string) { try { const d = new Date(iso); return { day: d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }), time: d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" }) }; } catch { return { day: iso, time: "" }; } }
function seriesWins(scores: { a: number; b: number }[] | undefined, side: "a" | "b") { if (!scores?.length) return 0; let w = 0; for (const g of scores) if (side === "a" ? g.a > g.b : g.b > g.a) w += 1; return w; }
function scoreLine(scores: { a: number; b: number }[] | undefined) { if (!scores?.length) return ""; return scores.map((g) => `${g.a}–${g.b}`).join(", "); }
function inviteScore(p: Player, friendIds: string[], now = Date.now()) { let score = 0; if (p.availability === "available") score += 1_000_000; else if (p.availability === "busy") score += 200_000; if (friendIds.includes(p.id)) score += 500_000; if (p.lastPlayedAt) { const age = now - new Date(p.lastPlayedAt).getTime(); score += Math.max(0, TWO_WEEKS_MS - age); } return score; }
function resolveCourt(match: Match, courts: Court[]) { const byId = courts.find((c) => c.id === match.courtId); if (byId) return byId; let best: Court | null = null; let bestD = Infinity; for (const c of courts) { const d = Math.hypot(c.lat - match.lat, c.lon - match.lon); if (d < bestD) { bestD = d; best = c; } } if (best && bestD < 0.01) return best; return { id: match.courtId, name: match.courtName, lat: match.lat, lon: match.lon }; }

export function QuickMatchFlow({
  me, players, courts, matches, userLat, userLon,
  onCreateMatch, onAcceptMatch, onOpenPlayer,
  compactHeader = false, onImmersiveChange,
  focusMatchId = null, onFocusMatchConsumed,
}: QuickMatchFlowProps) {
  const store = useUpsetStore();
  const [view, setView] = useState<View>("find");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [createCourtId, setCreateCourtId] = useState("");
  const [createWhen, setCreateWhen] = useState(() => {
    const d = new Date(Date.now() + 90 * 60e3);
    d.setMinutes(0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [createNotes, setCreateNotes] = useState(
    "Best of 3 · games to 11 · make it take it. Looking for someone my size and skill level.",
  );
  const [createStakeMode, setCreateStakeMode] = useState<StakeMode>("charity");
  const [createFormat, setCreateFormat] = useState<"1v1" | "horse">("1v1");
  const [createDollarsPerPoint, setCreateDollarsPerPoint] = useState(1);
  const [createStakePrice, setCreateStakePrice] = useState("20");
  const [createCap, setCreateCap] = useState("");
  const [showPeerStakes, setShowPeerStakes] = useState(false);
  const [createHood, setCreateHood] = useState("all");
  const [createSorts, setCreateSorts] = useState<Set<string>>(() => new Set());
  const [createRadiusMi, setCreateRadiusMi] = useState(5);
  const [createPickMode, setCreatePickMode] = useState<"photos" | "map">("photos");
  const [courtInfoId, setCourtInfoId] = useState<string | null>(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteQuery, setInviteQuery] = useState("");
  const [inviteFilters, setInviteFilters] = useState<Set<InviteFilter>>(
    () => new Set(),
  );
  const [inviteSorts, setInviteSorts] = useState<Set<InviteSortKey>>(
    () => new Set(),
  );
  const [chatDraft, setChatDraft] = useState("");
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [cancelError, setCancelError] = useState<string | null>(null);
  const [nearOrigin, setNearOrigin] = useState<{
    lat: number; lon: number; label: string; source: "gps" | "address";
  } | null>(null);
  const [locatingNear, setLocatingNear] = useState(false);
  const [nearLocError, setNearLocError] = useState<string | null>(null);
  const [showAddressEntry, setShowAddressEntry] = useState(false);
  const [addressQuery, setAddressQuery] = useState("");
  const [addressHits, setAddressHits] = useState<GeoHit[]>([]);
  const [addressSearching, setAddressSearching] = useState(false);

  // Deep-link from Media: open listing details
  useEffect(() => {
    if (!focusMatchId) return;
    const exists =
      matches.some((m) => m.id === focusMatchId) ||
      store.matches.some((m) => m.id === focusMatchId);
    if (!exists) {
      onFocusMatchConsumed?.();
      return;
    }
    setSelectedId(focusMatchId);
    setView("game");
    onFocusMatchConsumed?.();
  }, [focusMatchId, matches, store.matches, onFocusMatchConsumed]);

  const parentOrigin = {
    lat: userLat ?? AUSTIN_CENTER.lat,
    lon: userLon ?? AUSTIN_CENTER.lon,
  };
  const origin = nearOrigin
    ? { lat: nearOrigin.lat, lon: nearOrigin.lon }
    : parentOrigin;
  const hasPreciseLocation = !!nearOrigin;

  useEffect(() => {
    onImmersiveChange?.(view === "game" || view === "create");
    return () => onImmersiveChange?.(false);
  }, [view, onImmersiveChange]);

  useEffect(() => {
    if (!showAddressEntry) return;
    const q = addressQuery.trim();
    if (q.length < 3) {
      setAddressHits([]);
      setAddressSearching(false);
      return;
    }
    let cancelled = false;
    setAddressSearching(true);
    const tmr = window.setTimeout(async () => {
      const hits = await suggestAustinAddresses(q, 6);
      if (cancelled) return;
      setAddressHits(hits);
      setAddressSearching(false);
    }, 320);
    return () => { cancelled = true; window.clearTimeout(tmr); };
  }, [addressQuery, showAddressEntry]);

  const playerById = useMemo(() => new Map(players.map((p) => [p.id, p])), [players]);
  const friendIds = store.friendIds ?? [];

  const courtOptions = useMemo(
    () =>
      courts
        .map((c) => ({
          ...c,
          miles: haversineMi(origin.lat, origin.lon, c.lat, c.lon),
        }))
        .sort((a, b) => a.miles - b.miles)
        .slice(0, 40),
    [courts, origin.lat, origin.lon],
  );

  const openGames = useMemo(
    () =>
      matches
        .filter(
          (m) =>
            m.status === "open" &&
            m.hostId !== me.id &&
            (m.format ?? "1v1") === "1v1" &&
            inAustinMetro(m.lat, m.lon),
        )
        .map((m) => ({
          match: m,
          miles: haversineMi(origin.lat, origin.lon, m.lat, m.lon),
        }))
        .sort(
          (a, b) =>
            a.miles - b.miles ||
            a.match.preferredAt.localeCompare(b.match.preferredAt),
        ),
    [matches, me.id, origin.lat, origin.lon],
  );

  const selected = useMemo(() => {
    if (!selectedId) return null;
    return (
      matches.find((m) => m.id === selectedId) ??
      store.matches.find((m) => m.id === selectedId) ??
      null
    );
  }, [selectedId, matches, store.matches]);

  const upcomingGames = useMemo(
    () =>
      matches
        .filter((m) => {
          if (m.status === "cancelled") return false;
          if (m.status !== "matched" && m.status !== "scheduled") return false;
          return (
            m.hostId === me.id ||
            m.opponentId === me.id ||
            (m.rosterIds ?? []).includes(me.id)
          );
        })
        .sort((a, b) =>
          (a.scheduledAt ?? a.preferredAt).localeCompare(b.scheduledAt ?? b.preferredAt),
        ),
    [matches, me.id],
  );

  const myHostingOpen = useMemo(
    () => matches.filter((m) => m.hostId === me.id && m.status === "open"),
    [matches, me.id],
  );

  const inviteCandidates = useMemo(() => {
    const now = Date.now();
    let list = players.filter((p) => p.id !== me.id);
    if (inviteQuery.trim()) {
      const q = inviteQuery.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.handle.toLowerCase().includes(q) ||
          (p.neighborhood ?? "").toLowerCase().includes(q),
      );
    }
    // Multi-select filters (AND when multiple)
    if (inviteFilters.has("friends")) {
      list = list.filter((p) => friendIds.includes(p.id));
    }
    if (inviteFilters.has("available")) {
      list = list.filter((p) => p.availability === "available");
    }
    if (inviteFilters.has("active")) {
      list = list.filter(
        (p) =>
          p.availability === "available" ||
          (p.lastPlayedAt &&
            now - new Date(p.lastPlayedAt).getTime() < TWO_WEEKS_MS),
      );
    }
    // Multi-select sorts — apply selected keys in order: rating → height → streak
    // (only keys the user turned on). Unselected keys are ignored.
    return [...list].sort((a, b) => {
      if (inviteSorts.has("rating")) {
        const d = b.rating - a.rating;
        if (d !== 0) return d;
      }
      if (inviteSorts.has("height")) {
        const d = b.heightIn - a.heightIn;
        if (d !== 0) return d;
      }
      if (inviteSorts.has("streak")) {
        const d = (b.streak ?? 0) - (a.streak ?? 0);
        if (d !== 0) return d;
      }
      // Default / tie-break: online + friends + recent activity
      return inviteScore(b, friendIds, now) - inviteScore(a, friendIds, now);
    });
  }, [players, me.id, inviteQuery, inviteFilters, inviteSorts, friendIds]);

  const requestNearLocation = () => {
    setNearLocError(null);
    if (!navigator.geolocation) {
      setNearLocError("Location isn’t available on this device.");
      setShowAddressEntry(true);
      return;
    }
    setLocatingNear(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setNearOrigin({
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
          label: "Near you",
          source: "gps",
        });
        setLocatingNear(false);
        setShowAddressEntry(false);
        setNearLocError(null);
      },
      (err) => {
        setLocatingNear(false);
        setNearLocError(
          err.code === 1
            ? "Location permission denied."
            : "Couldn’t get GPS. Try typing an address.",
        );
        setShowAddressEntry(true);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60_000 },
    );
  };

  const pickAddressHit = (hit: GeoHit) => {
    setNearOrigin({
      lat: hit.lat,
      lon: hit.lon,
      label: hit.label,
      source: "address",
    });
    setAddressQuery(hit.label);
    setAddressHits([]);
    setShowAddressEntry(false);
    setNearLocError(null);
  };

  const startCreate = () => {
    setCreateCourtId("");
    setCreateSorts(new Set());
    setCourtInfoId(null);
    setView("create");
  };

  const submitCreate = () => {
    if (me.exiled) {
      setStatusMsg("You’re exiled from the league — cannot post games.");
      return;
    }
    if (!createCourtId) {
      setStatusMsg("Pick a court before posting.");
      return;
    }
    const court = courts.find((c) => c.id === createCourtId);
    if (!court) {
      setStatusMsg("Pick a court before posting.");
      return;
    }
    if (createStakeMode === "stakes") {
      const price = Number(createStakePrice);
      if (!Number.isFinite(price) || price < MIN_STAKE_DOLLARS) {
        setStatusMsg("Name your price — enter a dollar amount.");
        return;
      }
      if (price > MAX_STAKE_DOLLARS) {
        setStatusMsg(`Max stake is $${MAX_STAKE_DOLLARS.toLocaleString()}.`);
        return;
      }
    }
    const stakes: MatchStakes =
      createStakeMode === "stakes"
        ? {
            mode: "stakes",
            dollarsPerPoint: 1,
            fixedPriceDollars: Math.min(
              MAX_STAKE_DOLLARS,
              Math.max(MIN_STAKE_DOLLARS, Number(createStakePrice) || 20),
            ),
          }
        : createStakeMode === "charity"
          ? {
              mode: "charity",
              dollarsPerPoint: Math.max(0.5, Number(createDollarsPerPoint) || 1),
              ...(createCap.trim()
                ? { capDollars: Math.max(1, Number(createCap) || 0) }
                : {}),
              charityName: ALZHEIMERS_CHARITY.name,
              charityUrl: ALZHEIMERS_CHARITY.url,
            }
          : { mode: "fun", dollarsPerPoint: 1 };
    const formatLabel = createFormat === "horse" ? "HORSE" : "1v1";
    onCreateMatch?.({
      court: { id: court.id, name: court.name, lat: court.lat, lon: court.lon },
      preferredAt: new Date(createWhen).toISOString(),
      mode: "ranked_1v1",
      format: createFormat,
      notes: createNotes.trim(),
      stakes,
    });
    const postedPrice = Math.min(
      MAX_STAKE_DOLLARS,
      Math.max(MIN_STAKE_DOLLARS, Number(createStakePrice) || 20),
    );
    setStatusMsg(
      createStakeMode === "fun"
        ? `${formatLabel} posted — just for fun / rating.`
        : createStakeMode === "charity"
          ? `${formatLabel} for Alzheimer's posted — feeds the $50k city goal.`
          : `$${postedPrice} peer stakes posted.`,
    );
    setView("find");
  };

  const openGame = (id: string) => {
    setSelectedId(id);
    setView("game");
    setChatDraft("");
  };

  const joinGame = (id: string) => {
    if (me.exiled) {
      setStatusMsg("You’re exiled from the league — cannot join games.");
      return;
    }
    const r = onAcceptMatch?.(id);
    if (r === "filled") setStatusMsg("That game just filled.");
    else {
      setStatusMsg("You’re in — add phone reminders on the game page.");
      setSelectedId(id);
      setView("game");
    }
  };

  const aboutSheet =
    courtInfoId ? (
      <CourtAboutSheet
        court={
          courtOptions.find((c) => c.id === courtInfoId) ??
          courts.find((c) => c.id === courtInfoId) ??
          null
        }
        onClose={() => setCourtInfoId(null)}
        onSelectCourt={(id) => {
          setCreateCourtId(id);
          setCourtInfoId(null);
        }}
        isSelected={createCourtId === courtInfoId}
      />
    ) : null;

  // CREATE
  if (view === "create") {
    const hoods = Array.from(
      new Set(courtOptions.map((c) => c.neighborhood).filter((n): n is string => !!n && n.length > 0)),
    ).sort();
    const wantHighestRated = createSorts.has("highest_rated");
    const wantShaded = createSorts.has("shaded");
    const wantNearest = createSorts.has("nearest");

    let filteredCourts = [...courtOptions];
    if (createHood !== "all") {
      filteredCourts = filteredCourts.filter((c) => c.neighborhood === createHood);
    }
    if (wantShaded) filteredCourts = filteredCourts.filter((c) => isShadedCourt(c));
    if (wantNearest && hasPreciseLocation) {
      filteredCourts = filteredCourts.filter((c) => c.miles <= createRadiusMi + 0.05);
    }
    filteredCourts.sort((a, b) => {
      if (wantHighestRated) {
        const d = recommendScore(b) - recommendScore(a);
        if (d !== 0) return d;
      }
      return a.miles - b.miles;
    });

    const selectedCreateCourt = createCourtId
      ? filteredCourts.find((c) => c.id === createCourtId) ??
        courtOptions.find((c) => c.id === createCourtId)
      : undefined;
    const selectedThumb = selectedCreateCourt
      ? courtImagesFor(selectedCreateCourt.id, 1)[0]
      : null;

    return (
      <div className="space-y-2.5">
        <CampaignBanner compact />

        <button type="button" onClick={() => setView("find")} className="text-xs font-medium text-fg-muted">
          ← Back
        </button>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="font-display text-lg font-semibold text-fg">Create 1v1</h3>
            <p className="mt-0.5 text-[11px] text-fg-muted">Pick a court by photo or on the map.</p>
          </div>
          <div className="flex shrink-0 rounded-full border border-border bg-bg-elevated p-0.5">
            <button type="button" onClick={() => setCreatePickMode("photos")}
              className={cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", createPickMode === "photos" ? "bg-fg text-bg" : "text-fg-muted")}>
              Photos
            </button>
            <button type="button" onClick={() => setCreatePickMode("map")}
              className={cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", createPickMode === "map" ? "bg-fg text-bg" : "text-fg-muted")}>
              Map
            </button>
          </div>
        </div>

        {selectedCreateCourt ? (
          <div className="flex items-center gap-2 rounded-xl border border-court/40 bg-court/10 px-2 py-1.5">
            {selectedThumb ? (
              <img src={selectedThumb} alt="" className="size-10 shrink-0 rounded-lg object-cover" />
            ) : (
              <div className="size-10 shrink-0 rounded-lg bg-bg-subtle" />
            )}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1">
                <p className="truncate text-[13px] font-semibold text-fg">
                  {selectedCreateCourt.name.replace(/\s*Courts?\s*$/i, "") || selectedCreateCourt.name}
                </p>
                <button type="button" onClick={() => setCourtInfoId(selectedCreateCourt.id)}
                  className="flex size-5 shrink-0 items-center justify-center rounded-full bg-court/20 text-court" aria-label="About this court">
                  <Info className="size-3" strokeWidth={2.25} />
                </button>
              </div>
              <p className="truncate text-[11px] text-fg-muted">
                {selectedCreateCourt.neighborhood ?? "Austin"} · {formatMiles(selectedCreateCourt.miles)}
              </p>
            </div>
          </div>
        ) : null}

        <div className="space-y-1">
          <p className="text-[10px] font-medium text-fg-subtle">Optional filters · none selected is fine</p>
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {([
              { id: "highest_rated", label: "Highest rated" },
              { id: "shaded", label: "Shaded" },
              { id: "nearest", label: "Near me" },
            ] as const).map((opt) => {
              const on = createSorts.has(opt.id);
              return (
                <button key={opt.id} type="button"
                  onClick={() => {
                    setCreateSorts((prev) => {
                      const next = new Set(prev);
                      if (next.has(opt.id)) next.delete(opt.id);
                      else next.add(opt.id);
                      return next;
                    });
                  }}
                  className={cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold",
                    on ? "bg-court text-white" : "border border-border bg-bg-elevated text-fg-muted")}>
                  {on ? "✓ " : ""}{opt.label}
                </button>
              );
            })}
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <button type="button" onClick={() => setCreateHood("all")}
              className={cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold",
                createHood === "all" ? "border border-border bg-bg-elevated text-fg" : "bg-bg-elevated text-fg-muted")}>
              All areas
            </button>
            {hoods.map((h) => (
              <button key={h} type="button"
                onClick={() => setCreateHood((prev) => (prev === h ? "all" : h))}
                className={cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold",
                  createHood === h ? "bg-fg text-bg" : "border border-border bg-bg-elevated text-fg-muted")}>
                {h}
              </button>
            ))}
          </div>
        </div>

        {createSorts.has("nearest") ? (
          <div className="space-y-2 rounded-xl border border-border bg-bg-elevated px-2.5 py-2.5">
            {!hasPreciseLocation ? (
              <div className="space-y-2">
                <p className="text-[11px] font-semibold text-fg">Near me needs your location</p>
                <p className="text-[11px] leading-snug text-fg-muted">
                  Share GPS or type an address if location isn’t available.
                </p>
                <button type="button" onClick={requestNearLocation} disabled={locatingNear}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-court py-2.5 text-xs font-semibold text-white disabled:opacity-70">
                  <LocateFixed className="size-3.5" strokeWidth={2.25} />
                  {locatingNear ? "Getting location…" : "Share my location"}
                </button>
                {nearLocError ? <p className="text-[11px] text-danger" role="alert">{nearLocError}</p> : null}
                <button type="button" onClick={() => setShowAddressEntry(true)}
                  className="w-full text-center text-[11px] font-semibold text-court">
                  Type an address instead
                </button>
              </div>
            ) : (
              <div className="space-y-1.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-[10px] font-bold tracking-wide text-court uppercase">
                      {nearOrigin?.source === "gps" ? "GPS" : "Address"}
                    </p>
                    <p className="truncate text-[12px] font-semibold text-fg">{nearOrigin?.label ?? "Near you"}</p>
                  </div>
                  <button type="button" onClick={() => { setNearOrigin(null); setShowAddressEntry(true); setAddressQuery(""); }}
                    className="shrink-0 text-[11px] font-semibold text-fg-muted">Change</button>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[11px] font-semibold text-fg">Radius</p>
                  <p className="text-[12px] font-bold tabular-nums text-court">{createRadiusMi} mi</p>
                </div>
                <input type="range" min={1} max={25} step={1} value={createRadiusMi}
                  onChange={(e) => setCreateRadiusMi(Number(e.target.value))} className="w-full" aria-label="Search radius in miles" />
                <div className="flex gap-1 overflow-x-auto [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                  {[1, 3, 5, 8, 10, 15, 20, 25].map((mi) => (
                    <button key={mi} type="button" onClick={() => setCreateRadiusMi(mi)}
                      className={cn("shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold tabular-nums",
                        createRadiusMi === mi ? "bg-court text-white" : "bg-bg text-fg-muted")}>
                      {mi} mi
                    </button>
                  ))}
                </div>
              </div>
            )}
            {(showAddressEntry || (!hasPreciseLocation && nearLocError)) && (
              <div className="space-y-1.5 border-t border-border pt-2">
                <p className="text-[11px] font-semibold text-fg">Type an address</p>
                <div className="relative">
                  <input type="text" value={addressQuery}
                    onChange={(e) => { setAddressQuery(e.target.value); setShowAddressEntry(true); }}
                    placeholder="Street, park, or Austin address…" autoComplete="street-address"
                    className="w-full rounded-xl border border-border bg-bg px-3 py-2.5 text-sm text-fg outline-none focus:border-court" />
                  {addressSearching ? <p className="mt-1 text-[10px] text-fg-subtle">Looking up addresses…</p> : null}
                  {addressHits.length > 0 ? (
                    <ul className="absolute inset-x-0 top-full z-30 mt-1 max-h-48 overflow-y-auto rounded-xl border border-border bg-bg shadow-xl">
                      {addressHits.map((hit) => (
                        <li key={`${hit.lat}-${hit.lon}-${hit.label}`}>
                          <button type="button" onClick={() => pickAddressHit(hit)}
                            className="flex w-full items-start gap-2 px-3 py-2.5 text-left hover:bg-bg-elevated">
                            <MapPin className="mt-0.5 size-3.5 shrink-0 text-court" />
                            <span className="block text-[12px] font-semibold text-fg">{hit.label}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : addressQuery.trim().length >= 3 && !addressSearching ? (
                    <p className="mt-1 text-[10px] text-fg-subtle">No matches — try a street or landmark.</p>
                  ) : null}
                </div>
              </div>
            )}
          </div>
        ) : null}

        {createPickMode === "photos" ? (
          <>
            <div className="flex gap-2 overflow-x-auto pb-1 snap-x snap-mandatory [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {filteredCourts.map((c) => {
                const thumb = courtImagesFor(c.id, 1)[0];
                const selected = c.id === createCourtId;
                return (
                  <button key={c.id} type="button" onClick={() => setCreateCourtId(c.id)}
                    className={cn("w-[44%] max-w-[10.5rem] shrink-0 snap-start overflow-hidden rounded-2xl border text-left",
                      selected ? "border-court ring-2 ring-court/50 shadow-md" : "border-border bg-bg-elevated")}>
                    <div className="relative aspect-[5/4] bg-bg-subtle">
                      {thumb ? <img src={thumb} alt="" className="h-full w-full object-cover" loading="lazy" /> : null}
                      <button type="button"
                        onClick={(e) => { e.stopPropagation(); e.preventDefault(); setCourtInfoId(c.id); }}
                        className="absolute top-1.5 left-1.5 z-10 flex size-7 items-center justify-center rounded-full bg-black/55 text-white"
                        aria-label={`About ${c.name}`}>
                        <Info className="size-3.5" strokeWidth={2.25} />
                      </button>
                      <div className="absolute top-1.5 right-1.5 z-10 flex flex-col items-end gap-0.5">
                        {selected ? <span className="rounded-full bg-court px-1.5 py-0.5 text-[9px] font-bold text-white">✓</span> : null}
                        {isRecommendedCourt(c) ? <span className="rounded-full bg-fg/90 px-1.5 py-0.5 text-[8px] font-bold text-bg uppercase">Top</span> : null}
                        {isShadedCourt(c) ? <span className="rounded-full bg-black/55 px-1.5 py-0.5 text-[8px] font-bold text-white uppercase">Shade</span> : null}
                      </div>
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 pb-1.5 pt-6">
                        <p className="text-[10px] font-bold tracking-wide text-white uppercase">{c.neighborhood ?? "Austin"}</p>
                        <p className="text-[10px] font-medium text-white/90">{formatMiles(c.miles)} away</p>
                      </div>
                    </div>
                    <div className="px-2 py-1.5">
                      <p className="line-clamp-1 text-[12px] font-semibold text-fg">
                        {c.name.replace(/\s*Courts?\s*$/i, "") || c.name}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
            {filteredCourts.length === 0 ? (
              <p className="py-2 text-center text-xs text-fg-muted">No courts match. Expand radius or turn a filter off.</p>
            ) : !createCourtId ? (
              <p className="text-center text-[11px] text-fg-muted">Swipe and tap a court — or ⓘ for details.</p>
            ) : null}
          </>
        ) : (
          <div className="space-y-2">
            <p className="text-[11px] text-fg-muted">
              Tap a pin to open court info. Select it from the popup if you want that court.
            </p>
            <CourtsMap
              courts={filteredCourts}
              location={{ lat: origin.lat, lon: origin.lon, label: "You" }}
              selectedId={createCourtId || courtInfoId || null}
              onSelect={(c) => setCourtInfoId(c.id)}
              variant="finder"
            />
            {!createCourtId ? (
              <p className="text-center text-[11px] text-fg-muted">No court selected yet.</p>
            ) : null}
          </div>
        )}

        <label className="block space-y-1">
          <span className="text-[11px] font-medium text-fg-muted">When</span>
          <input type="datetime-local" value={createWhen} onChange={(e) => setCreateWhen(e.target.value)}
            className="w-full rounded-xl border border-border bg-bg-elevated px-3 py-2.5 text-sm text-fg" />
          {createStakeMode === "charity" ? (
            <div className="flex flex-wrap gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  const d = new Date();
                  d.setDate(d.getDate() + 1);
                  d.setHours(18, 0, 0, 0);
                  setCreateWhen(d.toISOString().slice(0, 16));
                }}
                className={cn(
                  "rounded-full px-3 py-1.5 text-[11px] font-bold",
                  (() => {
                    try {
                      const d = new Date(createWhen);
                      const t = new Date();
                      t.setDate(t.getDate() + 1);
                      return (
                        d.getFullYear() === t.getFullYear() &&
                        d.getMonth() === t.getMonth() &&
                        d.getDate() === t.getDate()
                      );
                    } catch {
                      return false;
                    }
                  })()
                    ? "bg-violet-600 text-white"
                    : "border border-violet-500/30 bg-violet-500/10 text-violet-800 dark:text-violet-200",
                )}
              >
                Play tomorrow · 6pm
              </button>
              <button
                type="button"
                onClick={() => {
                  const d = new Date();
                  d.setDate(d.getDate() + 1);
                  d.setHours(10, 0, 0, 0);
                  setCreateWhen(d.toISOString().slice(0, 16));
                }}
                className="rounded-full border border-border px-3 py-1.5 text-[11px] font-semibold text-fg-muted"
              >
                Tomorrow morning
              </button>
            </div>
          ) : null}
        </label>
        
        <div className="space-y-2 rounded-xl border border-border bg-bg-elevated p-3">
          <p className="text-[11px] font-bold text-fg">Game type</p>
          <div className="grid grid-cols-2 gap-1.5">
            {(
              [
                { id: "1v1" as const, label: "1v1", sub: "Games to 11" },
                { id: "horse" as const, label: "HORSE", sub: "Classic letters" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  setCreateFormat(opt.id);
                  if (opt.id === "horse") {
                    setCreateNotes((n) =>
                      n.includes("HORSE")
                        ? n
                        : "HORSE · outdoor · clean calls. Looking for a fun competitive run.",
                    );
                  }
                }}
                className={cn(
                  "rounded-xl border px-2 py-2.5 text-left",
                  createFormat === opt.id
                    ? "border-court bg-court-soft text-fg"
                    : "border-border bg-bg text-fg-muted",
                )}
              >
                <p className="text-[12px] font-bold">{opt.label}</p>
                <p className="text-[10px] opacity-80">{opt.sub}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2 rounded-xl border border-violet-500/25 bg-violet-500/5 p-3">
          <p className="text-[11px] font-bold text-fg">This game counts toward</p>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => {
                setCreateStakeMode("charity");
                setShowPeerStakes(false);
              }}
              className={cn(
                "rounded-xl border px-2 py-2.5 text-left",
                createStakeMode === "charity"
                  ? "border-violet-500 bg-violet-500/15 text-fg"
                  : "border-border bg-bg text-fg-muted",
              )}
            >
              <p className="text-[12px] font-bold">Alzheimer's $50k</p>
              <p className="text-[10px] opacity-80">City goal · give clean</p>
            </button>
            <button
              type="button"
              onClick={() => {
                setCreateStakeMode("fun");
                setShowPeerStakes(false);
              }}
              className={cn(
                "rounded-xl border px-2 py-2.5 text-left",
                createStakeMode === "fun"
                  ? "border-court bg-court-soft text-fg"
                  : "border-border bg-bg text-fg-muted",
              )}
            >
              <p className="text-[12px] font-bold">Just for fun</p>
              <p className="text-[10px] opacity-80">Rating only</p>
            </button>
          </div>

          {createStakeMode === "charity" ? (
            <div className="space-y-2 pt-1">
              <p className="text-[11px] leading-snug text-fg-muted">
                Loser donates $ per point of series margin to Alzheimer's
                research (ex: 10–2 + 10–5 = $13). It adds to Austin's{" "}
                <span className="font-semibold text-fg">$50,000</span> goal —
                not a peer bet.
              </p>
              <button
                type="button"
                onClick={() => {
                  const d = new Date();
                  d.setDate(d.getDate() + 1);
                  d.setHours(18, 0, 0, 0);
                  setCreateWhen(d.toISOString().slice(0, 16));
                  setStatusMsg(
                    "Tomorrow 6pm · charity run — pick a court and post.",
                  );
                }}
                className="flex h-11 w-full items-center justify-center rounded-xl bg-violet-600 text-sm font-semibold text-white"
              >
                Play tomorrow for Alzheimer's
              </button>
              <div className="grid grid-cols-2 gap-2">
                <label className="block text-[10px] font-medium text-fg-muted">
                  $/point of margin
                  <input
                    type="number"
                    min={0.5}
                    step={0.5}
                    value={createDollarsPerPoint}
                    onChange={(e) =>
                      setCreateDollarsPerPoint(Number(e.target.value) || 1)
                    }
                    className="mt-1 h-10 w-full rounded-xl border border-border bg-bg px-3 text-sm text-fg"
                  />
                </label>
                <label className="block text-[10px] font-medium text-fg-muted">
                  Cap $ (optional)
                  <input
                    type="number"
                    min={1}
                    placeholder="None"
                    value={createCap}
                    onChange={(e) => setCreateCap(e.target.value)}
                    className="mt-1 h-10 w-full rounded-xl border border-border bg-bg px-3 text-sm text-fg"
                  />
                </label>
              </div>
            </div>
          ) : createStakeMode === "fun" ? (
            <p className="text-[11px] text-fg-muted">
              Compete for rating and pride only. You can still join the $50k
              cause on your next run.
            </p>
          ) : null}

          <button
            type="button"
            onClick={() => {
              setShowPeerStakes((v) => !v);
              if (!showPeerStakes) setCreateStakeMode("stakes");
              else setCreateStakeMode("charity");
            }}
            className="text-[10px] font-medium text-fg-subtle underline-offset-2 hover:underline"
          >
            {showPeerStakes || createStakeMode === "stakes"
              ? "Hide peer cash options"
              : "Advanced: peer cash (not recommended)"}
          </button>

          {(showPeerStakes || createStakeMode === "stakes") && (
            <div className="space-y-2 rounded-xl border border-border bg-bg p-2.5">
              <p className="text-[11px] leading-snug text-fg-muted">
                Peer-to-peer cash is not the Upset City path. Prefer
                Alzheimer's so every game builds the city goal.
              </p>
              <button
                type="button"
                onClick={() => setCreateStakeMode("stakes")}
                className={cn(
                  "w-full rounded-xl border py-2 text-xs font-semibold",
                  createStakeMode === "stakes"
                    ? "border-fg bg-fg text-bg"
                    : "border-border text-fg-muted",
                )}
              >
                Peer stakes (name a $ price)
              </button>
              {createStakeMode === "stakes" ? (
                <>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-emerald-600">$</span>
                    <input
                      type="number"
                      min={MIN_STAKE_DOLLARS}
                      max={MAX_STAKE_DOLLARS}
                      value={createStakePrice}
                      onChange={(e) => {
                        const n = Number(e.target.value);
                        if (!Number.isFinite(n)) {
                          setCreateStakePrice(e.target.value);
                          return;
                        }
                        setCreateStakePrice(
                          String(Math.min(MAX_STAKE_DOLLARS, Math.max(0, n))),
                        );
                      }}
                      className="h-11 min-w-0 flex-1 border-0 border-b-2 border-border bg-transparent font-display text-2xl font-bold tabular-nums text-emerald-600 outline-none"
                    />
                  </div>
                  <p className="text-[10px] text-fg-subtle">
                    Max ${MAX_STAKE_DOLLARS.toLocaleString()} · unpaid = exile
                  </p>
                </>
              ) : null}
            </div>
          )}
        </div>

        <label className="block space-y-1">
          <span className="text-[11px] font-medium text-fg-muted">Notes · who you want</span>
          <textarea value={createNotes} onChange={(e) => setCreateNotes(e.target.value)} rows={2}
            placeholder="Size, skill band, vibe…"
            className="w-full rounded-xl border border-border bg-bg-elevated px-3 py-2.5 text-sm text-fg" />
        </label>
        <button type="button" onClick={submitCreate} disabled={!createCourtId}
          className={cn("w-full rounded-full py-3 text-sm font-semibold",
            createCourtId ? "bg-court text-white" : "cursor-not-allowed bg-bg-elevated text-fg-subtle")}>
          {createCourtId ? "Post open 1v1" : "Select a court to continue"}
        </button>

        {aboutSheet}
      </div>
    );
  }

  // GAME DETAIL
  if (view === "game" && selected) {
    const host = playerById.get(selected.hostId);
    const miles = haversineMi(origin.lat, origin.lon, selected.lat, selected.lon);
    const court = resolveCourt(selected, courts);
    const images = courtImagesFor(court.id, 4);
    const mapsHref = directionsUrl(court.lat, court.lon, court.name);
    const canInvite = selected.hostId === me.id && selected.status === "open";
    const canCancel =
      (selected.hostId === me.id || selected.opponentId === me.id) &&
      (selected.status === "open" || selected.status === "matched" || selected.status === "scheduled");
    const isHostView = selected.hostId === me.id;
    const someoneJoined =
      !!selected.opponentId ||
      selected.status === "matched" ||
      selected.status === "scheduled" ||
      (selected.rosterIds ?? []).some((id) => id !== selected.hostId);
    const hostEmptyCancel = isHostView && !someoneJoined;
    const opp = selected.opponentId ? playerById.get(selected.opponentId) : null;
    const { day, time } = whenParts(selected.scheduledAt ?? selected.preferredAt);

    return (
      <div className="space-y-3">
        <button type="button" onClick={() => { setView("find"); setSelectedId(null); }}
          className="text-xs font-medium text-fg-muted">← Back to open games</button>

        <div className="overflow-hidden rounded-2xl border border-border shadow-card">
          <div className="relative">
            <ImageCarousel images={images} alt={court.name} className="aspect-[16/9] w-full" priority />
            <div className="absolute top-1.5 left-1.5 z-20">
              <CourtMapCutout lat={court.lat} lon={court.lon} name={court.name}
                address={"address" in court ? court.address : undefined} size={56} zoom={12} />
            </div>
            <div className="absolute top-2 right-2 z-20 rounded-full bg-black/55 px-2 py-0.5 text-[9px] font-semibold tracking-wide text-white uppercase">
              {selected.format === "horse" ? "HORSE" : "Rated 1v1"}
                {selected.stakes?.mode === "charity" ? " · charity" : ""}
                {selected.status === "open" ? " · open" : ""}
            </div>
            <div className="absolute inset-x-0 bottom-2.5 z-20 flex items-center justify-center gap-3">
              <button type="button" onClick={() => host && onOpenPlayer?.(host)} disabled={!host} className="shrink-0">
                {host ? <PlayerAvatar player={host} size="md" className="!size-11 shadow-md ring-2 ring-white" />
                  : <div className="size-11 rounded-full bg-black/40 ring-2 ring-white/70" />}
              </button>
              <span className="font-display text-sm font-black tracking-[0.18em] text-court drop-shadow-[0_2px_4px_rgba(0,0,0,0.85)]">VS</span>
              <button type="button" onClick={() => opp && onOpenPlayer?.(opp)} disabled={!opp} className="shrink-0">
                {opp ? <PlayerAvatar player={opp} size="md" className="!size-11 shadow-md ring-2 ring-white" />
                  : <div className="flex size-11 items-center justify-center rounded-full border-2 border-dashed border-white/70 bg-black/35">
                      <span className="text-[8px] font-bold text-white uppercase">Open</span>
                    </div>}
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-2.5 rounded-2xl border border-border bg-bg-elevated p-3.5">
          <div>
            <h3 className="font-display text-base font-semibold text-fg">{court.name}</h3>
            <p className="mt-0.5 text-xs font-medium text-court">
              {formatMiles(miles)} away
              {"neighborhood" in court && court.neighborhood ? (
                <span className="font-normal text-fg-muted"> · {court.neighborhood}</span>
              ) : null}
            </p>
          </div>
          <div className="inline-flex items-center gap-1.5 rounded-lg bg-fg px-2.5 py-1.5 text-bg">
            <span className="text-xs font-bold tabular-nums">{day}</span>
            <span className="text-[10px] opacity-50">·</span>
            <span className="text-xs font-bold tabular-nums">{time}</span>
          </div>
          <p className="text-sm font-semibold text-fg">
            {selected.format === "horse"
              ? "HORSE · outdoor · clean calls"
              : "Best of 3 · games to 11 · make it take it"}
          </p>
          {selected.stakes ? (
            <StakeSettleCard
              match={selected}
              me={me}
              host={host}
              opp={opp}
              onMarkSettled={(method) =>
                store.markStakeSettled(selected.id, method)
              }
              onRequestExtension={(note) =>
                store.requestStakeExtension(selected.id, note)
              }
              onReportUnpaid={() => store.reportStakeUnpaid(selected.id)}
            />
          ) : (
            <p className="text-[11px] text-fg-muted">Just for fun · rating only</p>
          )}
          {"address" in court && court.address ? (
            <a href={mapsHref} target="_blank" rel="noopener noreferrer" className="flex items-start gap-1 text-sm text-fg-muted">
              <MapPin className="mt-0.5 size-3.5 shrink-0 opacity-70" />
              <span className="line-clamp-2">{court.address}</span>
            </a>
          ) : null}
        </div>

        {(selected.status === "matched" || selected.status === "scheduled") &&
        host &&
        opp ? (
          <MatchRemindersCard
            match={{
              id: selected.id,
              courtName: court.name,
              lat: selected.lat,
              lon: selected.lon,
              whenIso: selected.scheduledAt ?? selected.preferredAt,
              hostName: host.name,
              oppName: opp.name,
              notes: selected.notes,
            }}
          />
        ) : null}

        {selected.status === "open" ? (
          <HostScouting match={selected} host={host} me={me} players={players} matches={matches}
            reviews={store.playerReviews ?? []} isHost={selected.hostId === me.id}
            onSaveNotes={(notes) => store.updateMatchNotes(selected.id, notes)} onOpenPlayer={onOpenPlayer} />
        ) : null}

        <div className="space-y-2 rounded-xl border border-border bg-bg-elevated p-3">
          <div className="flex items-center gap-2">
            {host ? (
              <button type="button" onClick={() => onOpenPlayer?.(host)}>
                <PlayerAvatar player={host} size="sm" className="!size-8" />
              </button>
            ) : <MessageCircle className="size-3.5 text-fg-muted" />}
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold text-fg-muted">Game chat</p>
              {host ? <p className="truncate text-[11px] text-fg">Host · {host.name}</p> : null}
            </div>
          </div>
          <div className="max-h-40 space-y-2 overflow-y-auto">
            {(selected.chat ?? []).length === 0 ? (
              <p className="text-xs text-fg-subtle">No messages yet.</p>
            ) : (selected.chat ?? []).map((c) => {
              const author = c.authorId ? playerById.get(c.authorId) : undefined;
              return (
                <div key={c.id} className="flex items-start gap-2">
                  {author ? <PlayerAvatar player={author} size="xs" className="mt-0.5 !size-7" showRank={false} />
                    : <div className="mt-0.5 size-7 rounded-full bg-bg-subtle" />}
                  <p className="min-w-0 flex-1 text-xs">
                    <span className="font-semibold text-fg">{c.authorName}</span>
                    <span className="text-fg-muted"> · {c.text}</span>
                  </p>
                </div>
              );
            })}
          </div>
          <div className="flex items-center gap-2">
            <PlayerAvatar player={me} size="xs" className="!size-7 shrink-0" showRank={false} />
            <input value={chatDraft} onChange={(e) => setChatDraft(e.target.value)} placeholder="Message…"
              className="min-w-0 flex-1 rounded-full border border-border bg-bg px-3 py-2 text-sm" />
            <button type="button" onClick={() => { store.postMatchChat(selected.id, chatDraft); setChatDraft(""); }}
              className="rounded-full bg-fg px-3 py-2 text-xs font-semibold text-bg">Send</button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {selected.status === "open" && selected.hostId !== me.id ? (
            <button type="button" onClick={() => joinGame(selected.id)}
              className="min-w-[40%] flex-1 rounded-full bg-court py-3 text-sm font-semibold text-white">
              Join {selected.format === "horse" ? "HORSE" : "1v1"}
            </button>
          ) : null}
          {canInvite ? (
            <button type="button" onClick={() => setInviteOpen(true)}
              className="min-w-[40%] flex-1 rounded-full border border-border bg-bg-elevated py-3 text-sm font-semibold">Invite opponent</button>
          ) : null}
          {canCancel ? (
            <button type="button" onClick={() => { setCancelOpen(true); setCancelReason(""); setCancelError(null); }}
              className="min-w-[40%] flex-1 rounded-full border border-danger/40 bg-danger/10 py-3 text-sm font-semibold text-danger">
              {hostEmptyCancel ? "Close listing" : "Cancel game"}
            </button>
          ) : null}
        </div>

        {cancelOpen ? (
          <div className="fixed inset-0 z-[85] flex items-end justify-center bg-black/50 p-3 sm:items-center">
            <div className="w-full max-w-md rounded-2xl border border-border bg-bg p-4 shadow-xl">
              <p className="text-sm font-semibold text-fg">{hostEmptyCancel ? "Close this listing?" : "Cancel this game?"}</p>
              {!hostEmptyCancel ? (
                <textarea value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} rows={3}
                  className="mt-3 w-full rounded-xl border border-border bg-bg-elevated px-3 py-2 text-sm" placeholder="Why?" />
              ) : (
                <p className="mt-1 text-xs text-fg-muted">No one joined — free close, no penalty.</p>
              )}
              {cancelError ? <p className="mt-2 text-xs text-danger">{cancelError}</p> : null}
              <div className="mt-3 flex gap-2">
                <button type="button" onClick={() => setCancelOpen(false)} className="flex-1 rounded-full border border-border py-2.5 text-sm font-semibold">Keep</button>
                <button type="button" onClick={() => {
                  const r = store.cancelMatch(selected.id, hostEmptyCancel ? "" : cancelReason);
                  if (!r.ok) { setCancelError(r.reason); return; }
                  setCancelOpen(false); setStatusMsg("Game cancelled."); setView("find"); setSelectedId(null);
                }} className="flex-1 rounded-full bg-danger py-2.5 text-sm font-semibold text-white">Confirm</button>
              </div>
            </div>
          </div>
        ) : null}

        {inviteOpen ? (
          <InviteSheet
            candidates={inviteCandidates}
            query={inviteQuery}
            onQuery={setInviteQuery}
            filters={inviteFilters}
            onToggleFilter={(id) => {
              setInviteFilters((prev) => {
                const next = new Set(prev);
                if (next.has(id)) next.delete(id);
                else next.add(id);
                return next;
              });
            }}
            sorts={inviteSorts}
            onToggleSort={(id) => {
              setInviteSorts((prev) => {
                const next = new Set(prev);
                if (next.has(id)) next.delete(id);
                else next.add(id);
                return next;
              });
            }}
            invitedIds={selected.guestInviteIds ?? []}
            friendIds={friendIds}
            onInvite={(pid) => {
              const r = store.inviteToMatch(selected.id, pid);
              if (!r.ok) setStatusMsg(r.reason);
            }}
            onAddFriend={(pid) => store.addFriend(pid)}
            onClose={() => setInviteOpen(false)}
          />
        ) : null}
      </div>
    );
  }

  // FIND
  return (
    <div className="space-y-2.5">
      {statusMsg ? (
        <p className="rounded-lg bg-court/15 px-3 py-2 text-xs font-medium text-court">
          {statusMsg}
          <button type="button" className="ml-2 underline" onClick={() => setStatusMsg(null)}>dismiss</button>
        </p>
      ) : null}
      <div className="flex items-center justify-between gap-2">
        {!compactHeader ? (
          <div className="min-w-0">
            <p className="text-[11px] font-semibold tracking-[0.12em] text-court uppercase">Quick Match</p>
            <h3 className="font-display text-lg font-semibold text-fg">Find a run</h3>
          </div>
        ) : (
          <p className="text-[11px] text-fg-muted">{openGames.length} open 1v1s citywide</p>
        )}
        <button type="button" onClick={startCreate} className="shrink-0 rounded-full bg-court px-3 py-1.5 text-xs font-semibold text-white">
          <span className="inline-flex items-center gap-1"><Plus className="size-3.5" strokeWidth={2.5} />Create</span>
        </button>
      </div>
      <div className="flex rounded-xl border border-border bg-bg-elevated p-0.5">
        <div className="flex-1 rounded-lg bg-fg py-2 text-center text-[12px] font-semibold text-bg">1v1</div>
        {(["3v3", "5v5"] as const).map((label) => (
          <div key={label} className="flex flex-1 flex-col items-center justify-center py-1.5 opacity-40">
            <span className="text-[12px] font-semibold text-fg-muted">{label}</span>
            <span className="text-[8px] font-bold uppercase text-fg-subtle">Coming soon</span>
          </div>
        ))}
      </div>

      <CampaignBanner className="mb-1" />

      {upcomingGames.length > 0 ? (
        <div className="space-y-2">
          <p className="text-[11px] font-bold tracking-wide text-court uppercase">Upcoming games</p>
          {upcomingGames.map((m) => {
            const host = playerById.get(m.hostId);
            const oppP = m.opponentId ? playerById.get(m.opponentId) : null;
            const { day, time } = whenParts(m.scheduledAt ?? m.preferredAt);
            return (
              <button key={m.id} type="button" onClick={() => openGame(m.id)}
                className="flex w-full items-center gap-2.5 rounded-xl border border-court/40 bg-court/10 p-2.5 text-left">
                <div className="flex shrink-0 items-center gap-1">
                  {host ? <PlayerAvatar player={host} size="sm" /> : <div className="size-10 rounded-full bg-bg-subtle" />}
                  <span className="px-0.5 text-[10px] font-bold text-court uppercase">vs</span>
                  {oppP ? <PlayerAvatar player={oppP} size="sm" /> : (
                    <div className="flex size-10 items-center justify-center rounded-full border border-dashed border-border text-[9px]">?</div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-fg">{m.courtName}</p>
                  <div className="mt-0.5"><StakeChip stakes={m.stakes} /></div>
                  <div className="mt-1 inline-flex items-center gap-1.5 rounded-lg bg-fg px-2 py-1 text-bg">
                    <span className="text-[11px] font-bold">{day}</span><span className="opacity-50">·</span>
                    <span className="text-[11px] font-bold">{time}</span>
                  </div>
                </div>
                <ChevronRight className="size-4 text-fg-subtle" />
              </button>
            );
          })}
        </div>
      ) : null}

      {myHostingOpen.length > 0 ? (
        <div className="space-y-1.5">
          <p className="text-[10px] font-semibold uppercase text-fg-subtle">Your open posts</p>
          {myHostingOpen.map((m) => {
            const { day, time } = whenParts(m.preferredAt);
            return (
              <button key={m.id} type="button" onClick={() => openGame(m.id)}
                className="flex w-full items-center gap-3 rounded-xl border border-border bg-bg-elevated p-2.5 text-left">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{m.courtName}</p>
                  <div className="mt-0.5"><StakeChip stakes={m.stakes} /></div>
                  <div className="mt-1 inline-flex gap-1.5 rounded-lg bg-fg/90 px-2 py-1 text-bg">
                    <span className="text-[11px] font-bold">{day}</span><span className="opacity-50">·</span>
                    <span className="text-[11px] font-bold">{time}</span>
                  </div>
                </div>
                <span className="text-[11px] text-fg-subtle">Open</span>
              </button>
            );
          })}
        </div>
      ) : null}

      <div className="relative py-1">
        <div className="border-t border-border" />
        <div className="absolute inset-x-0 top-1/2 flex -translate-y-1/2 justify-center">
          <span className="bg-bg px-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-fg-subtle">Open games · city</span>
        </div>
      </div>

      {openGames.length === 0 ? (
        <div className="rounded-xl border border-border bg-bg-elevated px-4 py-8 text-center">
          <p className="text-sm text-fg-muted">No open 1v1s right now.</p>
          <button type="button" onClick={startCreate} className="mt-3 text-sm font-semibold text-court">Create one</button>
        </div>
      ) : (
        <div className="space-y-2">
          {openGames.map(({ match: m, miles }) => {
            const host = playerById.get(m.hostId);
            const { day, time } = whenParts(m.preferredAt);
            return (
              <button key={m.id} type="button" onClick={() => openGame(m.id)}
                className="flex w-full items-center gap-3 rounded-xl border border-border bg-bg-elevated p-2.5 text-left">
                {host ? <PlayerAvatar player={host} size="lg" className="!size-12" /> : <div className="size-12 rounded-full bg-bg-subtle" />}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">
                    {host?.name ?? "Host"}
                    {host ? <span className="ml-1.5 text-[11px] text-fg-muted">{displayRating(host.rating)}</span> : null}
                    {m.format === "horse" ? (
                      <span className="ml-1.5 text-[10px] font-bold text-court">HORSE</span>
                    ) : null}
                  </p>
                  <p className="truncate text-xs text-fg-muted">{m.courtName}</p>
                  <div className="mt-0.5"><StakeChip stakes={m.stakes} /></div>
                  <div className="mt-1.5 inline-flex gap-1.5 rounded-lg border border-border bg-bg-subtle px-2 py-1">
                    <span className="text-[11px] font-bold">{day}</span><span className="text-fg-subtle">·</span>
                    <span className="text-[11px] font-bold">{time}</span>
                  </div>
                  <p className="mt-1 flex items-center gap-1 text-[11px] text-fg-subtle">
                    <MapPin className="size-3" />{formatMiles(miles)} · rated 1v1
                  </p>
                </div>
                <ChevronRight className="size-4 text-fg-subtle" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function HostScouting({
  match, host, me, players, matches, reviews, isHost, onSaveNotes, onOpenPlayer,
}: {
  match: Match; host?: Player; me: Player; players: Player[]; matches: Match[];
  reviews: PlayerReview[]; isHost: boolean; onSaveNotes: (notes: string) => void;
  onOpenPlayer?: (p: Player) => void;
}) {
  const [editingNotes, setEditingNotes] = useState(false);
  const [noteDraft, setNoteDraft] = useState(match.notes ?? "");
  const [histOpen, setHistOpen] = useState(true);
  const [revOpen, setRevOpen] = useState(true);
  const [expandedMutualId, setExpandedMutualId] = useState<string | null>(null);
  const [historySheetOpen, setHistorySheetOpen] = useState(false);
  const [historyDetailId, setHistoryDetailId] = useState<string | null>(null);
  useEffect(() => { setNoteDraft(match.notes ?? ""); }, [match.id, match.notes]);
  const playerById = useMemo(() => new Map(players.map((p) => [p.id, p])), [players]);
  const hostHistory = useMemo(() => {
    if (!host) return [];
    return matches
      .filter((m) => m.status === "confirmed" && m.opponentId && (m.hostId === host.id || m.opponentId === host.id))
      .sort((a, b) => (b.scheduledAt ?? b.preferredAt).localeCompare(a.scheduledAt ?? a.preferredAt));
  }, [matches, host]);
  const myPastOpponents = useMemo(() => {
    const ids = new Set<string>();
    for (const m of matches) {
      if (m.status !== "confirmed" || !m.opponentId) continue;
      if (m.hostId === me.id) ids.add(m.opponentId);
      if (m.opponentId === me.id) ids.add(m.hostId);
    }
    return ids;
  }, [matches, me.id]);
  const mutual = useMemo(() => {
    if (!host) return [] as Array<{
      player: Player; hostResult: "W" | "L"; myResult: "W" | "L";
      hostWins: number; hostLosses: number; myWins: number; myLosses: number;
      hostScores: string; myScores: string; hostCourt: string; myCourt: string;
    }>;
    const out = [];
    for (const oppId of myPastOpponents) {
      if (oppId === host.id) continue;
      const hostMatch = hostHistory.find((m) => m.hostId === oppId || m.opponentId === oppId);
      if (!hostMatch) continue;
      const myMatch = matches.find(
        (m) => m.status === "confirmed" &&
          ((m.hostId === me.id && m.opponentId === oppId) || (m.opponentId === me.id && m.hostId === oppId)),
      );
      if (!myMatch) continue;
      const opp = playerById.get(oppId);
      if (!opp) continue;
      const hostIsA = hostMatch.hostId === host.id;
      const hostWins = seriesWins(hostMatch.scores, hostIsA ? "a" : "b");
      const hostLosses = seriesWins(hostMatch.scores, hostIsA ? "b" : "a");
      const meIsA = myMatch.hostId === me.id;
      const myWins = seriesWins(myMatch.scores, meIsA ? "a" : "b");
      const myLosses = seriesWins(myMatch.scores, meIsA ? "b" : "a");
      out.push({
        player: opp,
        hostResult: (hostWins > hostLosses ? "W" : "L") as "W" | "L",
        myResult: (myWins > myLosses ? "W" : "L") as "W" | "L",
        hostWins, hostLosses, myWins, myLosses,
        hostScores: scoreLine(hostMatch.scores), myScores: scoreLine(myMatch.scores),
        hostCourt: hostMatch.courtName, myCourt: myMatch.courtName,
      });
    }
    return out;
  }, [host, hostHistory, myPastOpponents, matches, me.id, playerById]);
  const hostReviews = useMemo(() => {
    if (!host) return [];
    return reviews.filter((r) => r.targetId === host.id).sort((a, b) => b.at.localeCompare(a.at));
  }, [reviews, host]);
  const avgStars = hostReviews.length > 0
    ? hostReviews.reduce((s, r) => s + r.stars, 0) / hostReviews.length : null;

  return (
    <div className="space-y-2.5">
      <div className="rounded-xl border border-border bg-bg-elevated p-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">Host notes · who they want</p>
          {isHost ? (
            <button type="button" onClick={() => {
              if (editingNotes) { onSaveNotes(noteDraft); setEditingNotes(false); }
              else setEditingNotes(true);
            }} className="text-[11px] font-semibold text-court">{editingNotes ? "Save" : "Edit"}</button>
          ) : null}
        </div>
        {editingNotes && isHost ? (
          <textarea value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} rows={3}
            className="mt-2 w-full rounded-xl border border-border bg-bg px-3 py-2 text-sm" />
        ) : (
          <p className="mt-1.5 text-sm leading-snug text-fg">
            {(match.notes ?? "").replace(/^Best of 3\s*[·•]\s*games to 11\s*[·•]\s*make it take it\.?\s*/i, "").trim() || "No notes yet."}
          </p>
        )}
      </div>
      {!isHost ? (
        <div className="rounded-xl border border-border bg-bg-elevated p-3">
          <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">Players you’ve both faced</p>
          {!host || mutual.length === 0 ? (
            <p className="mt-2 text-xs text-fg-muted">No shared opponents yet.</p>
          ) : (
            <div className="mt-2 space-y-2">
              {mutual.map((row) => {
                const open = expandedMutualId === row.player.id;
                const first = row.player.name.split(" ")[0] ?? row.player.name;
                return (
                  <div key={row.player.id} className="overflow-hidden rounded-xl border border-border bg-bg">
                    <button type="button" onClick={() => setExpandedMutualId(open ? null : row.player.id)}
                      className="flex w-full items-center gap-2.5 px-2.5 py-2 text-left">
                      <PlayerAvatar player={row.player} size="sm" className="!size-9" showRank={false} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{row.player.name}</p>
                        <p className="text-[11px] text-fg-muted">Host {row.hostResult} · You {row.myResult}</p>
                      </div>
                      <span className="text-[11px] text-fg-muted">{open ? "Hide" : "Results"}</span>
                    </button>
                    {open ? (
                      <div className="space-y-2 border-t border-border px-2.5 py-3">
                        <div className="rounded-xl bg-bg-elevated p-3">
                          <p className="text-[10px] font-bold uppercase text-fg-subtle">When {host.name.split(" ")[0]} played {first}</p>
                          <p className="mt-1 text-sm font-semibold">{row.hostResult} {row.hostWins}–{row.hostLosses}</p>
                          <p className="text-xs text-fg-muted">{row.hostScores || "—"} · {row.hostCourt}</p>
                        </div>
                        <div className="rounded-xl bg-bg-elevated p-3">
                          <p className="text-[10px] font-bold uppercase text-fg-subtle">When you played {first}</p>
                          <p className="mt-1 text-sm font-semibold">{row.myResult} {row.myWins}–{row.myLosses}</p>
                          <p className="text-xs text-fg-muted">{row.myScores || "—"} · {row.myCourt}</p>
                        </div>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : null}
      {!isHost ? (
        <>
          <div className="rounded-xl border border-border bg-bg-elevated p-3">
            <button type="button" onClick={() => setHistOpen((v) => !v)} className="flex w-full items-center justify-between">
              <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">
                Host history{host ? ` · ${host.wins}W–${host.losses}L · ${hostHistory.length}` : ""}
              </p>
              <span className="text-[11px] text-fg-muted">{histOpen ? "Hide" : "Show"}</span>
            </button>
            {histOpen ? (
              !host || hostHistory.length === 0 ? (
                <p className="mt-2 text-xs text-fg-muted">No games yet.</p>
              ) : (
                <div className="mt-2 space-y-1.5">
                  {hostHistory.slice(0, 3).map((m) => {
                    const hostIsA = m.hostId === host.id;
                    const oppId = hostIsA ? m.opponentId! : m.hostId;
                    const opp = playerById.get(oppId);
                    const wins = seriesWins(m.scores, hostIsA ? "a" : "b");
                    const losses = seriesWins(m.scores, hostIsA ? "b" : "a");
                    const won = wins > losses;
                    return (
                      <button key={m.id} type="button" onClick={() => { setHistoryDetailId(m.id); setHistorySheetOpen(true); }}
                        className="flex w-full items-center gap-2 rounded-lg bg-bg px-2.5 py-2 text-left">
                        {opp ? <PlayerAvatar player={opp} size="xs" className="!size-8" showRank={false} /> : <div className="size-8 rounded-full bg-bg-subtle" />}
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-semibold">vs {opp?.name ?? "Opponent"}</p>
                          <p className="truncate text-[10px] text-fg-muted">{m.courtName} · {scoreLine(m.scores)}</p>
                        </div>
                        <span className={won ? "text-xs font-bold text-success" : "text-xs font-bold text-danger"}>
                          {won ? "W" : "L"} {wins}–{losses}
                        </span>
                      </button>
                    );
                  })}
                  <button type="button" onClick={() => { setHistoryDetailId(null); setHistorySheetOpen(true); }}
                    className="w-full rounded-lg border border-border py-2.5 text-center text-xs font-semibold text-court">
                    View complete history ({hostHistory.length})
                  </button>
                </div>
              )
            ) : null}
          </div>
          {historySheetOpen && host ? (
            <HostHistorySheet host={host} games={hostHistory} playerById={playerById} focusId={historyDetailId}
              onClose={() => { setHistorySheetOpen(false); setHistoryDetailId(null); }} onOpenPlayer={onOpenPlayer} />
          ) : null}
        </>
      ) : null}
      {!isHost ? (
        <div className="rounded-xl border border-border bg-bg-elevated p-3">
          <button type="button" onClick={() => setRevOpen((v) => !v)} className="flex w-full items-center justify-between">
            <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">
              What players say{avgStars != null ? ` · ${avgStars.toFixed(1)}★ · ${hostReviews.length}` : ""}
            </p>
            <span className="text-[11px] text-fg-muted">{revOpen ? "Hide" : "Show"}</span>
          </button>
          {revOpen ? (
            hostReviews.length === 0 ? <p className="mt-2 text-xs text-fg-muted">No reviews yet.</p> : (
              <div className="mt-2 space-y-2">
                {hostReviews.map((r) => {
                  const author = playerById.get(r.authorId);
                  return (
                    <div key={r.id} className="rounded-lg border border-border bg-bg px-2.5 py-2">
                      <div className="flex items-center gap-2">
                        {author ? <PlayerAvatar player={author} size="xs" className="!size-7" showRank={false} /> : <div className="size-7 rounded-full bg-bg-subtle" />}
                        <p className="min-w-0 flex-1 truncate text-xs font-semibold">{r.authorName}</p>
                        <span className="text-[11px] font-bold text-court">{"★".repeat(r.stars)}</span>
                      </div>
                      <p className="mt-1 text-xs text-fg-muted">{r.text}</p>
                    </div>
                  );
                })}
              </div>
            )
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function HostHistorySheet({
  host, games, playerById, focusId, onClose, onOpenPlayer,
}: {
  host: Player; games: Match[]; playerById: Map<string, Player>; focusId: string | null;
  onClose: () => void; onOpenPlayer?: (p: Player) => void;
}) {
  const [expandedId, setExpandedId] = useState<string | null>(focusId);
  useEffect(() => { setExpandedId(focusId); }, [focusId]);
  return (
    <div className="fixed inset-0 z-[88] flex items-end justify-center bg-black/55 sm:items-center sm:p-4">
      <div className="flex max-h-[90dvh] w-full max-w-md flex-col overflow-hidden rounded-t-2xl border border-border bg-bg shadow-xl sm:rounded-2xl">
        <div className="flex items-start gap-3 border-b border-border px-4 py-3">
          <PlayerAvatar player={host} size="md" className="!size-12" />
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold uppercase text-court">Complete game history</p>
            <h3 className="truncate font-display text-lg font-semibold">{host.name}</h3>
            <p className="text-xs text-fg-muted">{host.wins}W–{host.losses}L · {displayRating(host.rating)}</p>
          </div>
          <button type="button" onClick={onClose} className="p-1.5"><X className="size-4" /></button>
        </div>
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
          {games.map((m) => {
            const hostIsA = m.hostId === host.id;
            const oppId = hostIsA ? m.opponentId! : m.hostId;
            const opp = playerById.get(oppId);
            const wins = seriesWins(m.scores, hostIsA ? "a" : "b");
            const losses = seriesWins(m.scores, hostIsA ? "b" : "a");
            const won = wins > losses;
            const open = expandedId === m.id;
            return (
              <div key={m.id} className="overflow-hidden rounded-xl border border-border bg-bg-elevated">
                <button type="button" onClick={() => setExpandedId(open ? null : m.id)}
                  className="flex w-full items-center gap-2.5 p-2.5 text-left">
                  {opp ? <PlayerAvatar player={opp} size="sm" className="!size-10" /> : <div className="size-10 rounded-full bg-bg-subtle" />}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">vs {opp?.name ?? "Opponent"}</p>
                    <p className="truncate text-[11px] text-fg-muted">{formatLocalWhen(m.scheduledAt ?? m.preferredAt)}</p>
                  </div>
                  <p className={won ? "text-sm font-black text-success" : "text-sm font-black text-danger"}>
                    {won ? "W" : "L"} {wins}–{losses}
                  </p>
                </button>
                {open ? (
                  <div className="space-y-1 border-t border-border px-3 py-2.5">
                    <p className="text-xs text-fg-muted">{m.courtName}</p>
                    {(m.scores ?? []).map((g, i) => {
                      const hostPts = hostIsA ? g.a : g.b;
                      const oppPts = hostIsA ? g.b : g.a;
                      return (
                        <div key={i} className="flex justify-between rounded-lg bg-bg px-2.5 py-1.5 text-xs">
                          <span className="text-fg-muted">Game {i + 1}</span>
                          <span className="font-semibold">{hostPts}–{oppPts}</span>
                        </div>
                      );
                    })}
                    {opp ? (
                      <button type="button" onClick={() => onOpenPlayer?.(opp)}
                        className="w-full pt-1 text-center text-[11px] font-semibold text-court">View profile</button>
                    ) : null}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
        <div className="border-t border-border p-3">
          <button type="button" onClick={onClose} className="w-full rounded-full bg-fg py-2.5 text-sm font-semibold text-bg">Done</button>
        </div>
      </div>
    </div>
  );
}

function InviteSheet({
  candidates,
  query,
  onQuery,
  filters,
  onToggleFilter,
  sorts,
  onToggleSort,
  invitedIds,
  friendIds,
  onInvite,
  onAddFriend,
  onClose,
}: {
  candidates: Player[];
  query: string;
  onQuery: (q: string) => void;
  filters: Set<InviteFilter>;
  onToggleFilter: (id: InviteFilter) => void;
  sorts: Set<InviteSortKey>;
  onToggleSort: (id: InviteSortKey) => void;
  invitedIds: string[];
  friendIds: string[];
  onInvite: (id: string) => void;
  onAddFriend: (id: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/50 p-3 sm:items-center">
      <div className="flex max-h-[85dvh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-border bg-bg shadow-xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="text-sm font-semibold">Invite opponent</p>
          <button type="button" onClick={onClose} className="p-2">
            <X className="size-4" />
          </button>
        </div>
        <div className="space-y-2 border-b border-border px-3 py-2">
          <div className="flex items-center gap-2 rounded-full border border-border bg-bg-elevated px-3 py-2">
            <Search className="size-3.5 text-fg-subtle" />
            <input
              value={query}
              onChange={(e) => onQuery(e.target.value)}
              placeholder="Search by name…"
              className="min-w-0 flex-1 bg-transparent text-sm outline-none"
            />
          </div>

          <div className="space-y-1.5">
            <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">
              Filter · pick any combo
            </p>
            <div className="flex flex-wrap gap-1">
              {(
                [
                  ["friends", "Friends"],
                  ["available", "Available"],
                  ["active", "Active"],
                ] as const
              ).map(([id, label]) => {
                const on = filters.has(id);
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onToggleFilter(id)}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[11px] font-semibold",
                      on ? "bg-fg text-bg" : "bg-bg-elevated text-fg-muted",
                    )}
                  >
                    {on ? "✓ " : ""}
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <p className="text-[10px] font-bold tracking-wide text-fg-subtle uppercase">
              Sort · pick any combo
            </p>
            <div className="flex flex-wrap gap-1">
              {(
                [
                  ["rating", "Player rating"],
                  ["height", "Height"],
                  ["streak", "Win streak"],
                ] as const
              ).map(([id, label]) => {
                const on = sorts.has(id);
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onToggleSort(id)}
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[11px] font-semibold",
                      on ? "bg-court text-white" : "border border-border bg-bg-elevated text-fg-muted",
                    )}
                  >
                    {on ? "✓ " : ""}
                    {label}
                  </button>
                );
              })}
            </div>
            {sorts.size > 0 ? (
              <p className="text-[10px] text-fg-subtle">
                Order:{" "}
                {[
                  sorts.has("rating") ? "rating" : null,
                  sorts.has("height") ? "height" : null,
                  sorts.has("streak") ? "streak" : null,
                ]
                  .filter(Boolean)
                  .join(" → ")}{" "}
                (high → low)
              </p>
            ) : (
              <p className="text-[10px] text-fg-subtle">
                Default: online & recent first
              </p>
            )}
          </div>
        </div>
        <div className="min-h-0 flex-1 space-y-1 overflow-y-auto p-2">
          {candidates.length === 0 ? (
            <p className="px-2 py-8 text-center text-xs text-fg-muted">
              No players match these filters.
            </p>
          ) : null}
          {candidates.map((p) => {
            const invited = invitedIds.includes(p.id);
            const isFriend = friendIds.includes(p.id);
            return (
              <div
                key={p.id}
                className="flex items-center gap-2 rounded-xl border border-border bg-bg-elevated px-2.5 py-2"
              >
                <PlayerAvatar player={p} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.name}</p>
                  <p className="truncate text-[11px] text-fg-muted">
                    {formatHeightInches(p.heightIn)}
                    {" · "}
                    {displayRating(p.rating)}
                    {(p.streak ?? 0) > 0 ? (
                      <span className="text-success">
                        {" · "}
                        {p.streak} streak
                      </span>
                    ) : null}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onAddFriend(p.id)}
                  className="p-1.5 text-fg-muted"
                >
                  <UserPlus
                    className={cn("size-3.5", isFriend && "text-court")}
                  />
                </button>
                <button
                  type="button"
                  disabled={invited}
                  onClick={() => onInvite(p.id)}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-semibold",
                    invited ? "bg-bg text-fg-subtle" : "bg-court text-white",
                  )}
                >
                  {invited ? "Invited" : "Invite"}
                </button>
              </div>
            );
          })}
        </div>
        <div className="border-t border-border p-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full rounded-full bg-fg py-2.5 text-sm font-semibold text-bg"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
