import { Heart } from "lucide-react";
import {
  CAMPAIGN_CHARITY,
  CAMPAIGN_TITLE,
  CAMPAIGN_YEAR,
  campaignProgress,
  formatCampaignMoney,
  useCampaign,
} from "@/lib/upset/campaign";
import { cn } from "@/lib/utils";

/** City cause progress — Play + Media */
export function CampaignBanner({
  compact,
  className,
}: {
  compact?: boolean;
  className?: string;
}) {
  const raised = useCampaign((s) => s.raisedDollars);
  const goal = useCampaign((s) => s.goalDollars);
  const { pct, remaining } = campaignProgress(raised, goal);

  if (compact) {
    return (
      <div
        className={cn(
          "rounded-xl border border-violet-500/25 bg-violet-500/8 px-3 py-2",
          className,
        )}
      >
        <div className="flex items-center gap-2">
          <Heart className="size-3.5 shrink-0 text-violet-600" strokeWidth={2.5} />
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <p className="truncate text-[11px] font-bold text-fg">
                {CAMPAIGN_TITLE}
              </p>
              <p className="shrink-0 text-[11px] font-bold tabular-nums text-violet-700 dark:text-violet-300">
                {formatCampaignMoney(raised)}
                <span className="font-medium text-fg-muted">
                  {" "}
                  / {formatCampaignMoney(goal)}
                </span>
              </p>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-violet-500/15">
              <div
                className="h-full rounded-full bg-violet-600 transition-[width] duration-500"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border border-violet-500/30 bg-gradient-to-br from-violet-500/12 via-bg-elevated to-bg-elevated p-3.5",
        className,
      )}
    >
      <div className="flex items-start gap-3">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-violet-600 text-white shadow-sm">
          <Heart className="size-4" strokeWidth={2.25} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-bold tracking-[0.14em] text-violet-700 uppercase dark:text-violet-300">
            {CAMPAIGN_YEAR} city goal
          </p>
          <h3 className="font-display text-base font-semibold text-fg">
            {CAMPAIGN_TITLE}
          </h3>
          <p className="mt-1 text-[11px] leading-snug text-fg-muted">
            Every game can feed {CAMPAIGN_CHARITY.short}. Compete hard. Give
            clean. No peer gambling — just rating, pride, and the cause.
          </p>
        </div>
      </div>

      <div className="mt-3">
        <div className="flex items-end justify-between gap-2">
          <div>
            <p className="text-[10px] font-medium text-fg-subtle uppercase">
              Raised
            </p>
            <p className="font-display text-2xl font-bold tabular-nums text-violet-700 dark:text-violet-300">
              {formatCampaignMoney(raised)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-medium text-fg-subtle uppercase">
              Goal
            </p>
            <p className="text-sm font-bold tabular-nums text-fg">
              {formatCampaignMoney(goal)}
            </p>
          </div>
        </div>
        <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-violet-500/15">
          <div
            className="h-full rounded-full bg-violet-600 transition-[width] duration-700"
            style={{ width: `${pct}%` }}
          />
        </div>
        <p className="mt-1.5 text-[11px] text-fg-muted">
          <span className="font-semibold text-fg">{pct}%</span>
          {" · "}
          {formatCampaignMoney(remaining)} to go ·{" "}
          <a
            href={CAMPAIGN_CHARITY.url}
            target="_blank"
            rel="noopener noreferrer"
            className="font-medium text-violet-700 underline-offset-2 hover:underline dark:text-violet-300"
          >
            {CAMPAIGN_CHARITY.name}
          </a>
        </p>
      </div>
    </div>
  );
}
