import { useMemo } from "react";
import { Crown } from "lucide-react";
import { useUpsetStore } from "@/lib/upset/store";
import { cn } from "@/lib/utils";
import type { Player } from "@/lib/upset/types";

const TOP_N = 50;

/**
 * Face-forward avatar — real photo when available, else color + initials.
 * #1: gold ring + crown
 * #2–10: cool platinum ring (elite hoopers)
 * showRank: optional #N chip left of face
 */
export function PlayerAvatar({
  player,
  size = "md",
  className,
  showRank = true,
  showElite = true,
}: {
  player: Pick<Player, "name" | "hue" | "photoUrl" | "id">;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  /** Show #rank chip left of face (top 50). Off on leaderboard rows. */
  showRank?: boolean;
  /** Crown / gold or platinum ring for top city ranks. Default on. */
  showElite?: boolean;
}) {
  const store = useUpsetStore();

  const rank = useMemo(() => {
    if (!player.id) return null;
    if (!showRank && !showElite) return null;
    const ordered = [...store.players]
      .filter((p) => p.city === "Austin" || !p.city)
      .sort((a, b) => b.rating - a.rating);
    const list =
      ordered.length > 0
        ? ordered
        : [...store.players].sort((a, b) => b.rating - a.rating);
    const idx = list.findIndex((p) => p.id === player.id);
    if (idx < 0 || idx >= TOP_N) return null;
    return idx + 1;
  }, [store.players, player.id, showRank, showElite]);

  const dim =
    size === "xs"
      ? "size-8"
      : size === "sm"
        ? "size-10"
        : size === "lg"
          ? "size-16"
          : size === "xl"
            ? "size-24"
            : "size-12";
  const text =
    size === "xs"
      ? "text-[10px]"
      : size === "sm"
        ? "text-xs"
        : size === "lg"
          ? "text-lg"
          : size === "xl"
            ? "text-2xl"
            : "text-sm";
  const badgeText =
    size === "xs" || size === "sm"
      ? "text-[10px] px-1 py-0.5 min-w-[1.2rem]"
      : size === "xl"
        ? "text-[13px] px-1.5 py-0.5 min-w-[1.6rem]"
        : "text-[11px] px-1.5 py-0.5 min-w-[1.35rem]";

  const crownSize =
    size === "xs"
      ? "size-2.5"
      : size === "sm"
        ? "size-3"
        : size === "lg"
          ? "size-4"
          : size === "xl"
            ? "size-5"
            : "size-3.5";

  const crownWrap =
    size === "xs"
      ? "-top-3 size-3.5"
      : size === "sm"
        ? "-top-3.5 size-4"
        : size === "lg"
          ? "-top-4 size-5"
          : size === "xl"
            ? "-top-5 size-6"
            : "-top-3.5 size-5";


  const initials = player.name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const src =
    player.photoUrl ??
    (player.id ? `/players/${player.id}.jpg` : undefined);

  const isTop10 = rank != null && rank <= 10;
  const isTop1 = rank === 1;
  const isElite = showElite && isTop10 && !isTop1;
  const showCrown = showElite && isTop1;
  const showGoldRing = showElite && isTop1;
  const showRankChip = showRank && rank != null;

  return (
    <div
      className={cn(
        "relative shrink-0",
        dim,
        showRankChip && "ml-3",
        // room so the crown sits fully above the head, not on the face
        showCrown &&
          (size === "xl"
            ? "mt-5"
            : size === "lg"
              ? "mt-4"
              : size === "xs"
                ? "mt-3"
                : "mt-3.5"),
        className,
      )}
    >
      {showCrown ? (
        <span
          className={cn(
            // centered above the portrait; bottom of crown just clears the gold ring
            "absolute left-1/2 z-20 flex -translate-x-1/2 items-center justify-center rounded-full bg-gold text-bg shadow-sm ring-1 ring-gold/50",
            crownWrap,
          )}
          title="City #1"
          aria-hidden
        >
          <Crown className={cn(crownSize, "fill-current")} strokeWidth={2} />
        </span>
      ) : null}

      <div
        className={cn(
          "relative z-[1] size-full overflow-hidden rounded-full shadow-sm",
          showGoldRing
            ? "ring-[2.5px] ring-gold ring-offset-1 ring-offset-bg"
            : isElite
              ? "ring-[2.5px] ring-offset-1 ring-offset-bg"
              : "ring-1 ring-border/80",
        )}
        style={
          showGoldRing
            ? {
                boxShadow:
                  "0 0 0 1px rgba(212,175,55,0.4), 0 0 10px rgba(212,175,55,0.35)",
                ...(src
                  ? {}
                  : {
                      background: `linear-gradient(145deg, oklch(0.48 0.09 ${player.hue}), oklch(0.32 0.06 ${player.hue}))`,
                    }),
              }
            : isElite
              ? {
                  // platinum ring — clean, shiny, no plate/label
                  boxShadow:
                    "0 0 0 2.5px #b8c4d6, 0 0 0 3.5px rgba(255,255,255,0.45), 0 0 10px rgba(190,205,225,0.5)",
                  ...(src
                    ? {}
                    : {
                        background: `linear-gradient(145deg, oklch(0.48 0.09 ${player.hue}), oklch(0.32 0.06 ${player.hue}))`,
                      }),
                }
              : src
                ? undefined
                : {
                    background: `linear-gradient(145deg, oklch(0.48 0.09 ${player.hue}), oklch(0.32 0.06 ${player.hue}))`,
                  }
        }
        aria-hidden
      >
        {src ? (
          <img
            src={src}
            alt=""
            width={size === "xl" ? 96 : size === "lg" ? 64 : 48}
            height={size === "xl" ? 96 : size === "lg" ? 64 : 48}
            className="size-full object-cover object-[center_20%]"
            loading="lazy"
            decoding="async"
            onError={(e) => {
              const el = e.currentTarget;
              el.style.display = "none";
              const parent = el.parentElement;
              if (parent) {
                parent.style.background = `linear-gradient(145deg, oklch(0.48 0.09 ${player.hue}), oklch(0.32 0.06 ${player.hue}))`;
                parent.classList.add(
                  "flex",
                  "items-center",
                  "justify-center",
                  "font-semibold",
                  "text-fg",
                  text,
                );
                if (!parent.querySelector("[data-initials]")) {
                  const span = document.createElement("span");
                  span.dataset.initials = "1";
                  span.textContent = initials;
                  parent.appendChild(span);
                }
              }
            }}
          />
        ) : (
          <div
            className={cn(
              "flex size-full items-center justify-center font-semibold text-fg",
              text,
            )}
          >
            {initials}
          </div>
        )}
      </div>

      {showRankChip ? (
        <span
          className={cn(
            "absolute -bottom-1 right-full z-10 translate-x-1.5 rounded-full text-center font-black tabular-nums leading-none shadow-sm ring-1",
            badgeText,
            isTop1
              ? "bg-gold text-bg ring-gold/40"
              : isTop10
                ? "bg-court text-white ring-court/30"
                : "bg-fg text-bg ring-border",
          )}
          title={`City ranking #${rank}`}
          aria-label={`Ranked #${rank} in Austin`}
        >
          #{rank}
        </span>
      ) : null}
    </div>
  );
}
