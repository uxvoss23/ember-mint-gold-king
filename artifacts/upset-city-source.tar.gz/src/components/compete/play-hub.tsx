import { useState } from "react";
import { Shield, X, Zap } from "lucide-react";
import { QuickMatchFlow } from "@/components/compete/quick-match-flow";
import { PlayerAvatar } from "@/components/compete/player-avatar";
import type { Player } from "@/lib/upset/types";
import type { Court } from "@/lib/courts/types";
import type { Match } from "@/lib/upset/types";
import { displayRating } from "@/lib/rating/engine";
import { cn } from "@/lib/utils";

interface PlayHubProps {
  me: Player;
  players: Player[];
  courts: Court[];
  matches: Match[];
  userLat?: number;
  userLon?: number;
  onOpenProfile?: () => void;
  onCreateMatch?: (input: {
    court: { id: string; name: string; lat: number; lon: number };
    preferredAt: string;
    mode: "ranked_1v1";
    format?: import("@/lib/upset/types").MatchFormat;
    notes?: string;
    stakes?: import("@/lib/upset/types").MatchStakes;
  }) => void;
  onAcceptMatch?: (matchId: string) => "ok" | "filled" | void;
  onOpenPlayer?: (p: Player) => void;
  focusMatchId?: string | null;
  onFocusMatchConsumed?: () => void;
}

/** Play hub — Quick Match live; Squads coming soon with explainer. */
export function PlayHub({
  me,
  players,
  courts,
  matches,
  userLat,
  userLon,
  onOpenProfile,
  onCreateMatch,
  onAcceptMatch,
  onOpenPlayer,
  focusMatchId,
  onFocusMatchConsumed,
}: PlayHubProps) {
  const [squadsInfo, setSquadsInfo] = useState(false);
  /** Hide Play chrome when viewing a game or create form */
  const [immersive, setImmersive] = useState(false);

  return (
    <div className="space-y-2.5">
      {!immersive ? (
        <>
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-[10px] font-semibold tracking-[0.12em] text-court uppercase">
                Play
              </p>
              <h2 className="font-display text-base font-semibold leading-tight tracking-tight text-fg">
                Find a run
              </h2>
              <p className="text-[11px] text-fg-subtle">
                Rated 1v1 live · teams coming soon
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenProfile}
              className="flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-bg-elevated py-0.5 pr-2.5 pl-0.5"
              aria-label="Your profile"
            >
              <PlayerAvatar player={me} size="sm" />
              <span className="text-xs font-semibold tabular-nums text-fg">
                {displayRating(me.rating)}
              </span>
            </button>
          </div>

          <div className="flex gap-1 rounded-full border border-border bg-bg-elevated p-0.5">
            <div className="flex flex-1 items-center justify-center gap-1 rounded-full bg-accent py-1.5 text-[11px] font-semibold text-accent-fg">
              <Zap className="size-3.5 shrink-0" strokeWidth={2} />
              Quick Match
            </div>
            <button
              type="button"
              onClick={() => setSquadsInfo(true)}
              className={cn(
                "relative flex flex-1 items-center justify-center gap-1 rounded-full py-1.5 text-[11px] font-semibold",
                "text-fg-subtle/70",
              )}
              aria-label="Squads coming soon"
            >
              <Shield className="size-3.5 shrink-0 opacity-60" strokeWidth={2} />
              <span className="truncate">Squads</span>
              <span className="absolute -top-1 right-0.5 rounded-full bg-bg-subtle px-1.5 py-px text-[8px] font-bold tracking-wide text-fg-muted uppercase ring-1 ring-border">
                Coming soon
              </span>
            </button>
          </div>
        </>
      ) : null}

      <QuickMatchFlow
        me={me}
        players={players}
        courts={courts}
        matches={matches}
        userLat={userLat}
        userLon={userLon}
        onCreateMatch={onCreateMatch}
        onAcceptMatch={onAcceptMatch}
        onOpenPlayer={onOpenPlayer}
        compactHeader
        onImmersiveChange={setImmersive}
        focusMatchId={focusMatchId}
        onFocusMatchConsumed={onFocusMatchConsumed}
      />

      {squadsInfo ? (
        <div
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/55 p-4 sm:items-center"
          role="dialog"
          aria-modal
          aria-labelledby="squads-soon-title"
          onClick={() => setSquadsInfo(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border border-border bg-bg p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="flex size-10 items-center justify-center rounded-full bg-bg-elevated ring-1 ring-border">
                  <Shield className="size-5 text-court" strokeWidth={2} />
                </div>
                <div>
                  <p className="text-[10px] font-semibold tracking-[0.14em] text-court uppercase">
                    Coming soon
                  </p>
                  <h3
                    id="squads-soon-title"
                    className="font-display text-lg font-semibold text-fg"
                  >
                    Squads
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSquadsInfo(false)}
                className="rounded-full p-1.5 text-fg-muted hover:bg-bg-elevated"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-fg">
              Build a crew of 3 or 5. Name it, claim a home court, and run as a
              unit against other Austin squads.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-fg-muted">
              We’re launching 1v1 first so everyone has a clear rating. Squad
              matchmaking and tournaments come next.
            </p>
            <button
              type="button"
              onClick={() => setSquadsInfo(false)}
              className="mt-5 w-full rounded-full bg-fg py-3 text-sm font-semibold text-bg"
            >
              Got it
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
