import { useState } from "react";
import { Heart, MapPin, Wrench } from "lucide-react";
import type { Court } from "@/lib/courts/types";
import { courtImagesFor } from "@/lib/courts/images";
import { useFavorites } from "@/lib/courts/favorites";
import {
  mergeCourtWithOverride,
  useCourtAdmin,
} from "@/lib/courts/admin-overrides";
import { isAdminEmail } from "@/lib/auth/admin";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { CourtMapCutout } from "@/components/court-map-cutout";
import { ImageCarousel } from "@/components/image-carousel";
import { WorkOrderPopup } from "@/components/work-order-popup";
import { AdminEditCourtButton } from "@/components/admin-court-editor";
import { directionsUrl } from "@/lib/maps/directions";
import { cn, formatDistance } from "@/lib/utils";

const AMENITY_LABEL: Record<string, string> = {
  lights: "Lights",
  full_court: "Full court",
  half_court: "Half court",
  multiple: "Multi-court",
  water: "Water",
  parking: "Parking",
  fence: "Fenced",
  shade: "Shaded",
};

interface CourtCardProps {
  court: Court;
  index: number;
  selected?: boolean;
  onSelect: (court: Court) => void;
}

export function CourtCard({ court, index, selected, onSelect }: CourtCardProps) {
  const favorites = useFavorites();
  const authUser = useCurrentUser();
  const admin = isAdminEmail(authUser?.primaryEmail);
  const ov = useCourtAdmin((s) => s.overrides[court.id]);
  const display = mergeCourtWithOverride(court, ov);
  const [woOpen, setWoOpen] = useState(false);
  const isFav = favorites.ids.includes(court.id);
  const images = courtImagesFor(court.id, 4, ov?.photos);
  const mapsHref = directionsUrl(display.lat, display.lon, display.name);

  return (
    <article
      className={cn(
        "group slide-up relative overflow-hidden rounded-2xl border bg-bg-elevated shadow-card transition-[border-color] duration-200",
        selected ? "border-court/50" : "border-border hover:border-border-strong",
        `stagger-${Math.min(index + 1, 4)}`,
      )}
    >
      <div className="relative">
        <ImageCarousel
          images={images}
          alt={display.name}
          className="aspect-[16/10]"
          priority={index < 2}
        />
        <div className="absolute top-1.5 left-1.5 z-20">
          <CourtMapCutout
            lat={display.lat}
            lon={display.lon}
            name={display.name}
            address={display.address}
            size={72}
            zoom={12}
          />
        </div>
        <div className="absolute top-2 right-2 z-20 flex items-center gap-1.5">
          {admin ? <AdminEditCourtButton court={display} /> : null}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setWoOpen(true);
            }}
            className="flex size-8 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm transition-colors hover:bg-black/50"
            aria-label={`Report issue at ${display.name}`}
            title="Work order"
          >
            <Wrench className="size-3.5" strokeWidth={1.75} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              favorites.toggle(court.id);
            }}
            className={cn(
              "flex size-8 items-center justify-center rounded-full backdrop-blur-sm transition-colors",
              isFav
                ? "bg-court/90 text-white"
                : "bg-black/35 text-white hover:bg-black/50",
            )}
            aria-label={isFav ? "Remove favorite" : "Save favorite"}
          >
            <Heart
              className={cn("size-3.5", isFav && "fill-current")}
              strokeWidth={1.75}
            />
          </button>
        </div>
      </div>

      <div className="space-y-2 p-3.5">
        <button
          type="button"
          onClick={() => onSelect(display)}
          className="min-w-0 w-full text-left"
        >
          <h2 className="truncate font-display text-base font-semibold tracking-tight text-fg">
            {display.name}
          </h2>
          <p className="mt-0.5 text-xs font-medium text-court">
            {formatDistance(display.distanceMeters)}
            {display.neighborhood ? (
              <span className="font-normal text-fg-muted">
                {" "}
                · {display.neighborhood}
              </span>
            ) : null}
          </p>
        </button>

        {display.address ? (
          <a
            href={mapsHref}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="flex items-start gap-1 text-sm text-fg-muted underline-offset-2 hover:text-court hover:underline"
          >
            <MapPin
              className="mt-0.5 size-3.5 shrink-0 opacity-70"
              strokeWidth={1.75}
            />
            <span className="line-clamp-1">{display.address}</span>
          </a>
        ) : null}

        <button
          type="button"
          onClick={() => onSelect(display)}
          className="block w-full text-left"
        >
          <div className="flex flex-wrap gap-1">
            {display.amenities.slice(0, 3).map((a) => (
              <span
                key={a}
                className="rounded-full border border-border bg-bg-subtle px-2 py-0.5 text-[10px] text-fg-muted"
              >
                {AMENITY_LABEL[a] ?? a}
              </span>
            ))}
            {display.hoops != null && (
              <span className="rounded-full border border-border bg-bg-subtle px-2 py-0.5 text-[10px] text-fg-muted">
                {display.hoops} hoop{display.hoops === 1 ? "" : "s"}
              </span>
            )}
          </div>
        </button>
      </div>

      <WorkOrderPopup
        courtId={court.id}
        courtName={display.name}
        open={woOpen}
        onClose={() => setWoOpen(false)}
      />
    </article>
  );
}
