import { useEffect, useMemo, useRef, useState } from "react";
import {
  Heart,
  List,
  LocateFixed,
  Map as MapIcon,
  Search,
  TreePine,
  X,
} from "lucide-react";
import { CourtCard } from "@/components/court-card";
import { CourtDetail } from "@/components/court-detail";
import { CourtsMap } from "@/components/courts-map";
import type { Court, UserLocation } from "@/lib/courts/types";
import { useFavorites } from "@/lib/courts/favorites";
import { cn } from "@/lib/utils";

type ViewMode = "list" | "map";

const RADIUS_MILES = [1, 2, 3, 5, 8, 10, 15, 20, 25] as const;

const RECOMMENDED_COURT_IDS = new Set([
  "cat-zilker",
  "cat-battle-bend",
  "cat-pease",
  "cat-bartholomew",
  "cat-rosewood",
  "cat-reed",
  "cat-circle-c",
  "cat-west4",
  "cat-garrison",
  "cat-walnut-creek",
  "cat-hancock",
  "cat-searight",
]);

function recommendScore(c: Court & { distanceMeters: number }) {
  let s = 0;
  if (RECOMMENDED_COURT_IDS.has(c.id)) s += 100;
  const a = new Set(c.amenities ?? []);
  if (a.has("shade")) s += 25;
  if (a.has("lights")) s += 20;
  if (a.has("parking")) s += 15;
  if (a.has("multiple")) s += 15;
  if (a.has("water")) s += 10;
  if (a.has("fence")) s += 8;
  if ((c.hoops ?? 0) >= 4) s += 12;
  s += Math.max(0, 15 - c.distanceMeters / 1609.34);
  return s;
}

export interface CourtsFinderProps {
  courts: Court[];
  location: UserLocation;
  loading: boolean;
  locating: boolean;
  error: string | null;
  locError: string | null;
  radiusMi: number;
  dataSource: string;
  onRadiusChange: (mi: number) => void;
  onRefresh: () => void;
  onNearMe: () => void;
  onQuickMatch?: (court: Court) => void;
}

function haversineM(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371000;
  const toR = (d: number) => (d * Math.PI) / 180;
  const dLat = toR(lat2 - lat1);
  const dLon = toR(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toR(lat1)) * Math.cos(toR(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

async function geocodeAustinAddress(
  q: string,
): Promise<{ lat: number; lon: number; label: string } | null> {
  const query = q.trim();
  if (query.length < 3) return null;
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.searchParams.set("q", `${query}, Austin, Texas`);
  url.searchParams.set("format", "json");
  url.searchParams.set("limit", "1");
  url.searchParams.set("countrycodes", "us");
  url.searchParams.set("viewbox", "-98.05,30.55,-97.45,30.05");
  url.searchParams.set("bounded", "1");
  try {
    const res = await fetch(url.toString(), {
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    const data = (await res.json()) as Array<{
      lat: string;
      lon: string;
      display_name: string;
    }>;
    const hit = data[0];
    if (!hit) return null;
    return {
      lat: Number(hit.lat),
      lon: Number(hit.lon),
      label: hit.display_name.split(",").slice(0, 2).join(","),
    };
  } catch {
    return null;
  }
}

export function CourtsFinder({
  courts,
  location,
  loading,
  locating,
  error,
  locError,
  radiusMi,
  dataSource,
  onRadiusChange,
  onRefresh,
  onNearMe,
  onQuickMatch,
}: CourtsFinderProps) {
  const favorites = useFavorites();
  const [filters, setFilters] = useState<Set<string>>(() => new Set());
  const [view, setView] = useState<ViewMode>("list");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Court | null>(null);
  const [searchOrigin, setSearchOrigin] = useState<{
    lat: number;
    lon: number;
    label: string;
  } | null>(null);
  const [searching, setSearching] = useState(false);
  const [searchMiss, setSearchMiss] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  void dataSource;

  const toggleFilter = (id: string) => {
    setFilters((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  const clearFilters = () => setFilters(new Set());

  useEffect(() => {
    const q = query.trim();
    if (q.length < 4) {
      setSearchOrigin(null);
      setSearchMiss(false);
      return;
    }
    let cancelled = false;
    const t = window.setTimeout(async () => {
      setSearching(true);
      const hit = await geocodeAustinAddress(q);
      if (cancelled) return;
      setSearching(false);
      if (hit) {
        setSearchOrigin(hit);
        setSearchMiss(false);
      } else {
        setSearchOrigin(null);
        setSearchMiss(true);
      }
    }, 450);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [query]);

  useEffect(() => {
    if (searchOpen) {
      const id = requestAnimationFrame(() => inputRef.current?.focus());
      return () => cancelAnimationFrame(id);
    }
  }, [searchOpen]);

  const origin = searchOrigin ?? {
    lat: location.lat,
    lon: location.lon,
  };

  const filtered = useMemo(() => {
    let list = courts.map((c) => ({
      ...c,
      distanceMeters: haversineM(origin.lat, origin.lon, c.lat, c.lon),
    }));

    if (filters.has("favorites")) {
      list = list.filter((c) => favorites.ids.includes(c.id));
    }
    if (filters.has("shade")) {
      list = list.filter((c) => c.amenities.includes("shade"));
    }

    list.sort((a, b) => {
      if (filters.has("highest_rated")) {
        const d = recommendScore(b) - recommendScore(a);
        if (d !== 0) return d;
      }
      return a.distanceMeters - b.distanceMeters;
    });
    return list;
  }, [courts, filters, favorites.ids, origin.lat, origin.lon]);

  const closeSearch = () => {
    setSearchOpen(false);
    setQuery("");
    setSearchOrigin(null);
    setSearchMiss(false);
  };

  return (
    <div className="space-y-3">
      {locError && (
        <p className="text-center text-xs text-fg-muted" role="status">
          {locError}
        </p>
      )}

      <div className="flex items-center gap-1.5">
        {searchOpen ? (
          <div className="relative flex min-w-0 flex-1 items-center">
            <Search
              className="pointer-events-none absolute left-2.5 size-3.5 text-fg-subtle"
              strokeWidth={1.75}
            />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type an address…"
              className="h-9 w-full rounded-xl border border-border bg-bg-elevated pr-9 pl-8 text-sm text-fg placeholder:text-fg-subtle outline-none focus:border-border-strong"
              aria-label="Search by address"
            />
            <button
              type="button"
              onClick={closeSearch}
              className="absolute right-1.5 flex size-7 items-center justify-center rounded-lg text-fg-muted"
              aria-label="Close search"
            >
              <X className="size-3.5" />
            </button>
          </div>
        ) : (
          <>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="flex size-9 shrink-0 items-center justify-center rounded-xl border border-border bg-bg-elevated text-fg-muted hover:text-fg"
              aria-label="Search by address"
            >
              <Search className="size-4" strokeWidth={1.75} />
            </button>
            <div className="flex min-w-0 flex-1 gap-1 overflow-x-auto [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <button
                type="button"
                onClick={clearFilters}
                className={cn(
                  "shrink-0 rounded-full px-2.5 py-1.5 text-[11px] font-medium",
                  filters.size === 0
                    ? "bg-accent text-accent-fg"
                    : "bg-bg-elevated text-fg-muted hover:text-fg",
                )}
              >
                All
              </button>
              {(
                [
                  { id: "favorites", label: "Saved", icon: Heart },
                  { id: "shade", label: "Shaded", icon: TreePine },
                  { id: "highest_rated", label: "Highest rated" },
                ] as const
              ).map((f) => {
                const on = filters.has(f.id);
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => toggleFilter(f.id)}
                    className={cn(
                      "inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] font-medium",
                      on
                        ? "bg-accent text-accent-fg"
                        : "bg-bg-elevated text-fg-muted hover:text-fg",
                    )}
                  >
                    {"icon" in f && f.icon ? (
                      <f.icon
                        className={cn(
                          "size-3",
                          f.id === "favorites" && on && "fill-current",
                        )}
                        strokeWidth={1.75}
                      />
                    ) : null}
                    {on ? "✓ " : ""}
                    {f.label}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>

      <div className="flex items-center justify-between gap-2">
        <p className="min-w-0 flex-1 truncate text-[11px] text-fg-subtle">
          {searching
            ? "Finding that address…"
            : searchOrigin
              ? `Closest to ${searchOrigin.label}`
              : searchMiss
                ? "Address not found — try a street in Austin"
                : loading
                  ? "Loading…"
                  : `${filtered.length} court${filtered.length === 1 ? "" : "s"}${
                      filters.has("highest_rated")
                        ? " · highest rated first"
                        : " · nearest first"
                    }`}
        </p>

        <div className="flex shrink-0 items-center gap-1.5">
          <select
            value={radiusMi}
            onChange={(e) => onRadiusChange(Number(e.target.value))}
            className="h-8 rounded-lg border border-border bg-bg-elevated px-2 text-[11px] font-medium text-fg outline-none"
            aria-label="Radius"
          >
            {RADIUS_MILES.map((m) => (
              <option key={m} value={m}>
                {m} mi
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={onNearMe}
            disabled={locating}
            className="flex size-8 items-center justify-center rounded-lg bg-accent text-accent-fg disabled:opacity-60"
            aria-label="Near me"
          >
            <LocateFixed className="size-3.5" strokeWidth={1.75} />
          </button>

          <div className="flex rounded-lg bg-bg-subtle p-0.5">
            <button
              type="button"
              onClick={() => setView("list")}
              className={cn(
                "flex size-7 items-center justify-center rounded-md",
                view === "list"
                  ? "bg-bg-elevated text-fg shadow-sm"
                  : "text-fg-subtle",
              )}
              aria-label="List view"
            >
              <List className="size-3.5" strokeWidth={1.75} />
            </button>
            <button
              type="button"
              onClick={() => setView("map")}
              className={cn(
                "flex size-7 items-center justify-center rounded-md",
                view === "map"
                  ? "bg-bg-elevated text-fg shadow-sm"
                  : "text-fg-subtle",
              )}
              aria-label="Map view"
            >
              <MapIcon className="size-3.5" strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-danger/30 bg-danger/10 px-3 py-2 text-sm">
          {error}
          <button
            type="button"
            className="ml-2 font-medium text-court underline-offset-2 hover:underline"
            onClick={onRefresh}
          >
            Retry
          </button>
        </div>
      )}

      {loading && courts.length === 0 ? (
        <div className="space-y-2.5">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="overflow-hidden rounded-2xl border border-border bg-bg-elevated"
            >
              <div className="aspect-[16/10] animate-pulse bg-bg-subtle" />
              <div className="space-y-2 p-3">
                <div className="h-4 w-2/3 animate-pulse rounded bg-bg-subtle" />
                <div className="h-3 w-1/3 animate-pulse rounded bg-bg-subtle" />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          filters={filters}
          onClear={clearFilters}
          onRefresh={onRefresh}
        />
      ) : view === "map" ? (
        <CourtsMap
          courts={filtered}
          location={
            searchOrigin
              ? {
                  lat: searchOrigin.lat,
                  lon: searchOrigin.lon,
                  label: searchOrigin.label,
                }
              : location
          }
          selectedId={selected?.id}
          onSelect={setSelected}
          variant="finder"
        />
      ) : (
        <div className="space-y-2.5">
          {filtered.map((court, i) => (
            <CourtCard
              key={court.id}
              court={court}
              index={i}
              selected={selected?.id === court.id}
              onSelect={setSelected}
            />
          ))}
        </div>
      )}

      <CourtDetail
        court={selected}
        onClose={() => setSelected(null)}
        onQuickMatch={(c) => {
          setSelected(null);
          onQuickMatch?.(c);
        }}
      />
    </div>
  );
}

function EmptyState({
  filters,
  onClear,
  onRefresh,
}: {
  filters: Set<string>;
  onClear: () => void;
  onRefresh: () => void;
}) {
  const hasFav = filters.has("favorites");
  const hasShade = filters.has("shade");
  return (
    <div className="fade-in flex flex-col items-center rounded-2xl border border-border bg-bg-elevated px-6 py-10 text-center">
      <h2 className="font-display text-base font-semibold text-fg">
        {hasFav && !hasShade
          ? "No saved courts yet"
          : hasShade || filters.size > 0
            ? "No courts match these filters"
            : "No courts in range"}
      </h2>
      <p className="mt-1.5 max-w-xs text-sm text-fg-muted">
        {hasFav && filters.size === 1
          ? "Tap the heart on a court to save it."
          : "Widen the radius, clear a filter, or search an address."}
      </p>
      <div className="mt-4 flex gap-2">
        {filters.size > 0 && (
          <button
            type="button"
            onClick={onClear}
            className="rounded-full border border-border px-3.5 py-1.5 text-sm font-medium text-fg"
          >
            Clear filters
          </button>
        )}
        <button
          type="button"
          onClick={onRefresh}
          className="rounded-full bg-court px-3.5 py-1.5 text-sm font-semibold text-white"
        >
          Refresh
        </button>
      </div>
    </div>
  );
}
