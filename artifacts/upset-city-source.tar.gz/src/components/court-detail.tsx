import { useRef, useState } from "react";
import {
  ExternalLink,
  Flag,
  Heart,
  MapPin,
  Navigation,
  Star,
  Swords,
  Camera,
  ImagePlus,
  Wrench,
  X,
} from "lucide-react";
import type { Court } from "@/lib/courts/types";
import { courtImagesFor } from "@/lib/courts/images";
import { useFavorites } from "@/lib/courts/favorites";
import {
  favoriteCountFor,
  reviewsFor,
  useCourtSocial,
  WORK_ORDER_LABELS,
  type WorkOrderKind,
} from "@/lib/courts/social";
import { CourtMapCutout } from "@/components/court-map-cutout";
import { AdminEditCourtButton } from "@/components/admin-court-editor";
import {
  mergeCourtWithOverride,
  useCourtAdmin,
} from "@/lib/courts/admin-overrides";
import { isAdminEmail } from "@/lib/auth/admin";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { compressWorkOrderPhoto } from "@/components/work-order-popup";
import { ImageCarousel } from "@/components/image-carousel";
import { directionsUrl } from "@/lib/maps/directions";
import { cn, formatDistance } from "@/lib/utils";

const AMENITY_LABEL: Record<string, string> = {
  lights: "Lights",
  full_court: "Full court",
  half_court: "Half court",
  multiple: "Multi-court",
  water: "Water",
  parking: "Parking",
  fence: "Fenced",
  shade: "Shaded",
};

interface CourtDetailProps {
  court: Court | null;
  onClose: () => void;
  onQuickMatch?: (court: Court) => void;
}

export function CourtDetail({ court, onClose, onQuickMatch }: CourtDetailProps) {
  const favorites = useFavorites();
  const social = useCourtSocial();
  const [tab, setTab] = useState<"info" | "reviews" | "report">("info");
  const [reviewText, setReviewText] = useState("");
  const [reviewStars, setReviewStars] = useState(5);
  const [woKind, setWoKind] = useState<WorkOrderKind>("broken_rim");
  const [woOther, setWoOther] = useState("");
  const [woMsg, setWoMsg] = useState<string | null>(null);
  const [woPhotos, setWoPhotos] = useState<string[]>([]);
  const [woPicking, setWoPicking] = useState(false);
  const woCamRef = useRef<HTMLInputElement>(null);
  const woLibRef = useRef<HTMLInputElement>(null);

  const authUser = useCurrentUser();
  const ov = useCourtAdmin((s) => (court ? s.overrides[court.id] : undefined));
  const admin = isAdminEmail(authUser?.primaryEmail);

  if (!court) return null;

  const display = mergeCourtWithOverride(court, ov);
  const isFav = favorites.ids.includes(court.id);
  const images = courtImagesFor(court.id, 5, ov?.photos);
  const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${display.lat},${display.lon}`;
  const favCount = favoriteCountFor(court.id, isFav, social.favoriteBonus);
  const courtReviews = reviewsFor(social.reviews, court.id);
  const avgReview =
    courtReviews.reduce((s, r) => s + r.rating, 0) / Math.max(1, courtReviews.length);
  const courtOrders = social.workOrders.filter((w) => w.courtId === court.id);

  const toggleFav = () => {
    const was = favorites.ids.includes(court.id);
    favorites.toggle(court.id);
    if (!was) social.bumpFavorite(court.id);
  };

  const submitReview = () => {
    if (!reviewText.trim()) return;
    social.addReview(court.id, reviewStars, reviewText);
    setReviewText("");
    setReviewStars(5);
  };

  const submitWorkOrder = () => {
    if (woKind === "other" && !woOther.trim()) {
      setWoMsg("Please describe the issue.");
      return;
    }
    social.addWorkOrder(
      court.id,
      woKind,
      woKind === "other" ? woOther : undefined,
      {
        courtName: display.name,
        reporter: "You",
        photos: woPhotos.length ? woPhotos : undefined,
        photoUrl: woPhotos[0],
      },
    );
    setWoMsg("Work order submitted — parks staff will review.");
    setWoOther("");
    setWoPhotos([]);
  };

  const pickWoPhoto = async (files: FileList | File[] | null) => {
    const list = files
      ? Array.from(files).filter((f) => f.type.startsWith("image/"))
      : [];
    if (!list.length) return;
    setWoPicking(true);
    setWoMsg(null);
    try {
      const urls: string[] = [];
      for (const f of list) urls.push(await compressWorkOrderPhoto(f));
      setWoPhotos((prev) => [...prev, ...urls]);
    } catch {
      setWoMsg("Couldn’t read one of those photos — try again.");
    } finally {
      setWoPicking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        type="button"
        className="absolute inset-0 bg-bg/70 backdrop-blur-sm fade-in"
        aria-label="Dismiss"
        onClick={onClose}
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="court-detail-title"
        className="slide-up relative z-10 flex max-h-[94dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border border-border bg-bg-elevated shadow-soft sm:rounded-3xl"
      >
        <div className="relative shrink-0">
          <ImageCarousel
            images={images}
            alt={display.name}
            className="h-[min(28dvh,176px)] w-full"
            priority
          />
          <div className="absolute top-1.5 left-1.5 z-20">
            <CourtMapCutout
              lat={display.lat}
              lon={display.lon}
              name={display.name}
              address={display.address}
              size={64}
              zoom={12}
            />
          </div>
          <div className="absolute top-3 right-3 z-20 flex gap-2">
            {admin ? <AdminEditCourtButton court={display} /> : null}
            <button
              type="button"
              onClick={toggleFav}
              className={cn(
                "flex size-10 items-center justify-center rounded-full border backdrop-blur-md",
                isFav
                  ? "border-court/40 bg-court/25 text-court"
                  : "border-border bg-bg/55 text-fg",
              )}
            >
              <Heart className={cn("size-4", isFav && "fill-current")} strokeWidth={1.75} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex size-10 items-center justify-center rounded-full border border-border bg-bg/55 text-fg backdrop-blur-md"
            >
              <X className="size-4" strokeWidth={1.75} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pt-2.5 pb-5 safe-pb">
          <div>
            <div className="mb-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm font-medium text-court">
              <span className="inline-flex items-center gap-1">
                <Navigation className="size-3.5" strokeWidth={2.25} />
                {formatDistance(display.distanceMeters)} away
              </span>
              {display.neighborhood && (
                <span className="text-fg-subtle">· {display.neighborhood}</span>
              )}
            </div>
            <h2
              id="court-detail-title"
              className="font-display text-2xl font-semibold tracking-tight text-fg"
            >
              {display.name}
            </h2>
            {display.address && (
              <a
                href={directionsUrl(display.lat, display.lon, display.name)}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-1 flex items-start gap-1.5 text-sm text-court underline-offset-2 hover:underline"
              >
                <MapPin className="mt-0.5 size-3.5 shrink-0" strokeWidth={1.75} />
                <span>
                  <span className="underline decoration-court/40">{display.address}</span>
                  <span className="mt-0.5 block text-[11px] font-medium text-fg-subtle no-underline">
                    Open in Maps for directions
                  </span>
                </span>
              </a>
            )}
          </div>

          {/* Compact social strip */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-fg-muted">
            <span className="inline-flex items-center gap-1 font-medium">
              <Heart className="size-3 text-court" strokeWidth={2} />
              <span className="tabular-nums text-fg">{favCount}</span>
              favorited
            </span>
            <span className="text-fg-subtle">·</span>
            <span className="inline-flex items-center gap-1 font-medium">
              <Star className="size-3 text-gold" strokeWidth={2} />
              <span className="tabular-nums text-fg">{avgReview.toFixed(1)}</span>
              <span>({courtReviews.length})</span>
            </span>
          </div>

          <div className="flex gap-1 overflow-x-auto rounded-full border border-border bg-bg-subtle p-1 no-scrollbar">
            {(
              [
                { id: "info" as const, label: "Details" },
                { id: "reviews" as const, label: "Reviews" },
                { id: "report" as const, label: "Work order" },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  "shrink-0 rounded-full px-3 py-2 text-xs font-semibold transition-colors",
                  tab === t.id ? "bg-accent text-accent-fg" : "text-fg-muted",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          {tab === "info" && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {display.amenities.map((a) => (
                  <span
                    key={a}
                    className="rounded-full border border-border bg-bg-subtle px-3 py-1 text-xs font-medium text-fg-muted"
                  >
                    {AMENITY_LABEL[a] ?? a}
                  </span>
                ))}
                {display.surface !== "unknown" && (
                  <span className="rounded-full border border-border bg-bg-subtle px-3 py-1 text-xs font-medium capitalize text-fg-muted">
                    {display.surface}
                  </span>
                )}
                {display.hoops ? (
                  <span className="rounded-full border border-border bg-bg-subtle px-3 py-1 text-xs font-medium text-fg-muted">
                    {display.hoops} hoops
                  </span>
                ) : null}
              </div>
              {display.notes && (
                <p className="text-sm leading-relaxed text-fg-muted">{display.notes}</p>
              )}
              {display.hours && (
                <p className="text-xs text-fg-subtle">Hours · {display.hours}</p>
              )}
              {display.lightsHours && (
                <p className="text-xs text-fg-subtle">Lights · {display.lightsHours}</p>
              )}
            </div>
          )}

          {tab === "reviews" && (
            <div className="space-y-3">
              <div className="space-y-2">
                {courtReviews.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-xl border border-border bg-bg-subtle px-3 py-2.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold text-fg">{r.author}</p>
                      <span className="flex items-center gap-0.5 text-xs font-medium text-gold">
                        {Array.from({ length: r.rating }, (_, i) => (
                          <Star key={i} className="size-3 fill-current" strokeWidth={0} />
                        ))}
                      </span>
                    </div>
                    <p className="mt-1 text-sm leading-relaxed text-fg-muted">{r.text}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-xl border border-border bg-bg-subtle p-3 space-y-2">
                <p className="text-xs font-medium tracking-wide text-fg-subtle uppercase">
                  Write a review
                </p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setReviewStars(n)}
                      className={cn(
                        "p-1",
                        n <= reviewStars ? "text-gold" : "text-fg-subtle",
                      )}
                    >
                      <Star
                        className={cn("size-5", n <= reviewStars && "fill-current")}
                        strokeWidth={1.75}
                      />
                    </button>
                  ))}
                </div>
                <textarea
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  rows={2}
                  placeholder="How’s the court?"
                  className="w-full resize-none rounded-xl border border-border bg-bg-elevated px-3 py-2 text-sm text-fg outline-none"
                />
                <button
                  type="button"
                  onClick={submitReview}
                  className="h-10 w-full rounded-xl bg-accent text-sm font-semibold text-accent-fg"
                >
                  Post review
                </button>
              </div>
            </div>
          )}

          {tab === "report" && (
            <div className="space-y-3">
              <div className="flex items-start gap-2 rounded-xl border border-border bg-bg-subtle px-3 py-3">
                <Wrench className="mt-0.5 size-4 shrink-0 text-fg-muted" strokeWidth={1.75} />
                <p className="text-sm text-fg-muted">
                  Request maintenance for this court. Pick an issue or describe
                  something else.
                </p>
              </div>
              <div className="space-y-2">
                {(
                  [
                    { id: "broken_rim" as const, label: "Broken rim" },
                    { id: "replace_net" as const, label: "Replace net" },
                    { id: "other" as const, label: "Something else" },
                  ] as const
                ).map((opt) => (
                  <label
                    key={opt.id}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-3 text-sm",
                      woKind === opt.id
                        ? "border-court bg-court-soft text-fg"
                        : "border-border bg-bg-subtle text-fg-muted",
                    )}
                  >
                    <input
                      type="radio"
                      name="wo"
                      checked={woKind === opt.id}
                      onChange={() => setWoKind(opt.id)}
                      className="accent-[var(--color-court)]"
                    />
                    {opt.label}
                  </label>
                ))}
              </div>
              {woKind === "other" && (
                <textarea
                  value={woOther}
                  onChange={(e) => setWoOther(e.target.value)}
                  rows={3}
                  placeholder="Describe the issue…"
                  className="w-full resize-none rounded-xl border border-border bg-bg-subtle px-3 py-2.5 text-sm text-fg outline-none"
                  required
                />
              )}
              <div className="space-y-2">
                <p className="text-[11px] font-semibold text-fg-muted">
                  Photos (optional) · select many at once
                </p>
                {woPhotos.length > 0 ? (
                  <div className="grid grid-cols-3 gap-1.5">
                    {woPhotos.map((src, i) => (
                      <div
                        key={`${i}-${src.slice(0, 16)}`}
                        className="relative aspect-square overflow-hidden rounded-lg border border-border"
                      >
                        <img src={src} alt="" className="size-full object-cover" />
                        <button
                          type="button"
                          onClick={() =>
                            setWoPhotos((prev) => prev.filter((_, j) => j !== i))
                          }
                          className="absolute top-1 right-1 rounded-full bg-black/55 p-1 text-white"
                          aria-label="Remove photo"
                        >
                          <X className="size-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : null}
                <div className="flex gap-2">
                  <input
                    ref={woCamRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={(e) => {
                      void pickWoPhoto(e.target.files);
                      e.target.value = "";
                    }}
                  />
                  <input
                    ref={woLibRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      void pickWoPhoto(e.target.files);
                      e.target.value = "";
                    }}
                  />
                  <button
                    type="button"
                    disabled={woPicking}
                    onClick={() => woCamRef.current?.click()}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-border bg-bg-subtle py-2.5 text-xs font-semibold text-fg disabled:opacity-60"
                  >
                    <Camera className="size-3.5" />
                    Take photo
                  </button>
                  <button
                    type="button"
                    disabled={woPicking}
                    onClick={() => woLibRef.current?.click()}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-border bg-bg-subtle py-2.5 text-xs font-semibold text-fg disabled:opacity-60"
                  >
                    <ImagePlus className="size-3.5" />
                    {woPhotos.length ? "Add more" : "Upload"}
                  </button>
                </div>
              </div>
              <button
                type="button"
                onClick={submitWorkOrder}
                disabled={woPicking}
                className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-accent text-sm font-semibold text-accent-fg disabled:opacity-60"
              >
                <Wrench className="size-4" strokeWidth={2} />
                Submit work order
              </button>
              {woMsg && (
                <p className="text-center text-xs text-fg-muted" role="status">
                  {woMsg}
                </p>
              )}
              {courtOrders.length > 0 && (
                <div className="space-y-2 pt-2">
                  <p className="text-xs font-medium tracking-wide text-fg-subtle uppercase">
                    Your requests
                  </p>
                  {courtOrders.map((w) => (
                    <div
                      key={w.id}
                      className="rounded-lg border border-border bg-bg-subtle px-3 py-2 text-xs text-fg-muted"
                    >
                      <div className="flex gap-2">
                        {(w.photos?.length ? w.photos : w.photoUrl ? [w.photoUrl] : []).slice(0, 3).map((src, i) => (
                          <img
                            key={i}
                            src={src}
                            alt=""
                            className="size-12 shrink-0 rounded-md object-cover"
                          />
                        ))}
                        <div className="min-w-0">
                          {WORK_ORDER_LABELS[w.kind]}
                          {w.detail ? ` — ${w.detail}` : ""} · {w.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}


          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={() => onQuickMatch?.(display)}
              className="col-span-2 flex h-12 items-center justify-center gap-2 rounded-xl bg-court text-sm font-semibold text-white active:scale-[0.98]"
            >
              <Swords className="size-4" strokeWidth={2} />
              Create game here
            </button>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 items-center justify-center gap-2 rounded-xl border border-border-strong bg-bg-subtle text-sm font-medium text-fg"
            >
              Directions
              <ExternalLink className="size-3.5 opacity-70" strokeWidth={1.75} />
            </a>
            <button
              type="button"
              onClick={onClose}
              className="flex h-11 items-center justify-center rounded-xl border border-border-strong bg-bg-subtle text-sm font-medium text-fg"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
